python3 csvMain.py
code archivo.csv