#-*- coding: utf-8 -*-

class Node:
    def __init__(self,value):
        self.value =Value
        self.next=None
        self.children=Linkedlist()

class Linkedlist:
        def _init_(self):
        self.first = None

    def push(self,value,pos=0):
        if not self.first:
            self.first = Node(value)
            return True
        
        count = 0
        current = self.first
        if count == pos:
            self.first = Node(value)
            self.first = current

        prev = self.first
        current = prev.next

        while current:
            count +=1
            if count == pos:
                   prev.next = Node(value)
                   prev.next.next = current
                   return True
            prev = current
            current = prev.next

        prev.next = Node(value)
        return True

    def print(self):
        current = self.first

        result = '|=> '
        while current:
            result += "%s" % (current.value) + ' '
            current = current.next

        return result

    

class Folder :
    def