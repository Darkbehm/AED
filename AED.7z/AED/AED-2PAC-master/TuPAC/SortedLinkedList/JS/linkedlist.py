class linkedList:
    def _init_(self):
        self.first = None

    def push(self,value,pos=0):
        if not self.first:
            self.first = Node(value)
            return True
        
        count = 0
        current = self.first
        if count == pos:
            self.first = Node(value)
            self.first = current

        prev = self.first
        current = prev.next

        while current:
            count +=1
            if count == pos:
                   prev.next = Node(value)
                   prev.next.next = current
                   return True
            prev = current
            current = prev.next

        prev.next = Node(value)
        return True

    def print(self):
        current = self.first

        result = '|=> '
        while current:
            result += "%s" % (current.value) + ' '
            current = current.next

        return result


class Node:
    def _init_(self,value):
        self.value = value
        self.next = None
        self.children = linkedList()
        
class treeTDA:
    def _init_(self):
        self.root = Node("root")

    def push(self,value,current=None):
        if not current:
            current = self.root

        current.children.push(value)
    
    def search(self,value,current=None):
        if not current:
            current= self.root

        current.children.search(value)


    def length(self):
        count = 0
        current = self.root
        count += current.children.length()


    def _str_(self):
        return self.root.children.print()