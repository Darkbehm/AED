    //Estructura de Dato (Lista Enlazada)
    /*function ListaEnlazada(){
        this.primero = null;
    }*/

    //TDA (Nodo)

    //Objeto (Valor)

    console.log("prueba");