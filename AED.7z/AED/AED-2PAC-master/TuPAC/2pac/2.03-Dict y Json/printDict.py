def printDict(dct,tab=0):
     for key,value in dct.items():
        if(isinstance(value,dict)):
            print("%s%s" % ("\t"*(tab),key))
            printDict(value,tab+1)
        else:  
            print("%s%s : %s" % ("\t"*(tab),key,value))
            