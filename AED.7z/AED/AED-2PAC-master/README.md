# AED-2PAC
Todos sino la mayoría de los programas realizados en la clase de Algoritmos y estructura de datos.

Características:</br>
-Los nombres de variables y funciones fueron escritas en inglés.</br>
-Para cada programa, se encuentran dos versiones, cada una con su nombre de carpeta, en Python3 (Python) y JavaScript(JS).
