import os
from os import listdir
from os.path import isfile, join, isdir,exists
from datetime import datetime
class FileManager:
   def __init__(self):
      pass

   #funcion para crear las carpetas donde se guardaran los archivos encriptado
   #copia la estructura de subcarpetas de la ruta de origen en la ruta de destino 
   #en 2 carpetas diferentes(AES_256 y OWNAlgorithm)
   #llamara a la otra funcion recursiva 
   def makeEncryptDirectorie(self,originRoute= '.',destinationRoute ='.'):
      if not exists(destinationRoute+'/AES_256'):
         os.makedirs(destinationRoute+'/AES_256')
      self.makeDirectorieInner(originRoute,destinationRoute+'/AES_256')
      if not exists(destinationRoute+'/OWNAlgorithm'):
         os.makedirs(destinationRoute+'/OWNAlgorithm')
      self.makeDirectorieInner(originRoute,destinationRoute+'/OWNAlgorithm')

   def makeEncryptFileDirectorie(self,destinationRoute = '.'):
      if not exists(destinationRoute+'/AES_256'):
         os.makedirs(destinationRoute+'/AES_256')
      if not exists(destinationRoute+'/OWNAlgorithm'):
         os.makedirs(destinationRoute+'/OWNAlgorithm')

   def makeDecryptFileDirectorie(self,destinationRoute = '.'):
      if not exists(destinationRoute+'/DESC_AES_256'):
         os.makedirs(destinationRoute+'/DESC_AES_256')
      if not exists(destinationRoute+'/DESC_OWNAlgorithm'):
         os.makedirs(destinationRoute+'/DESC_OWNAlgorithm')


   #funcion para crear las carpetas donde se guardaran los archivos desencriptados
   #copia la estructura de subcarpetas de la ruta de origen en la ruta de destino 
   #en 2 carpetas diferentes(AES_256 y OWNAlgorithm)
   #llamara a la otra funcion recursiva 
   def makeDecryptDirectorie(self,originRoute= '.',destinationRoute ='.'):
      if not exists(destinationRoute+'/DESC_AES_256'):
         os.makedirs(destinationRoute+'/DESC_AES_256')
      self.makeDirectorieInner(originRoute,destinationRoute+'/DESC_AES_256')
      if not exists(destinationRoute+'/DESC_OWNAlgorithm'):
         os.makedirs(destinationRoute+'/DESC_OWNAlgorithm')
      self.makeDirectorieInner(originRoute,destinationRoute+'/DESC_OWNAlgorithm')

   #funcion recursiva para crear todos los directorios a partir de otra ruta, 
   #los crea con todas las subcarpetas que existan en la ruta de origen 
   def makeDirectorieInner(self,originRoute , destinationRoute ):
      directorios=self.getDirectorieList(originRoute)
      for d in directorios:
         if not exists(destinationRoute+'/'+d):
            os.makedirs(destinationRoute+'/'+d)
         self.makeDirectorieInner(originRoute+'/'+d,destinationRoute+'/'+d)
      return True
   
   
   #devuelve una lista de los nombres de los archivos que existen 
   #en una ruta raiz(root)
   def getArchive(self,root):
      return [arch for arch in listdir(root) if isfile(join(root, arch))]

   #devuelve una lista de los nombres de los directorios 
   #y sub directorios que existen en una ruta raiz(root)
   def getDirectorieList(self,root):
      return [subdir for subdir in listdir(root) if isdir(join(root, subdir)) and not (subdir =='AES_256' or subdir == 'OWNAlgorithm' or subdir =='DESC_OWNAlgorithm' or subdir =='DESC_AES_256') ]

   def writeHTML(self,destinationRoute,content):
      with open(destinationRoute + '/' + 'LOG_' + self.getTime() + ".html" , 'w') as fo:
            fo.write(content)

   def writeJSON(self,destinationRoute,content):
      with open(destinationRoute + '/' + 'LOG_' + self.getTime() + ".json" , 'w') as fo:
            fo.write(str(content))
            fo.close()

   def openJSON(self,route):
      with open(route,'r') as fo:
         json=fo.read()
         json=eval(json)
         fo.close()
         return json

   def getAllArchives(self,route,count=0):
      count+= len(self.getArchive(route))
      for dir in self.getDirectorieList(route):
         count =self.getAllArchives(route+'/'+dir,count)
      return count

   def getTime(self):
      time=str(datetime.now())
      date,time = time.split(' ')
      datearray= date.split('-')
      timearray= time.split(':')
      second= timearray[-1].split('.')
      timearray[-1]= second[0]
      finalArray= datearray+timearray
      result= '_'.join(finalArray) 
      return result