import sys
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog , QDesktopWidget
from PyQt5.QtGui import QIcon

class Ui_OpenFile(QWidget):

    def __init__(self):
        super().__init__()
        self.title = 'Abrir Archivo/Carpeta'
        self.left = 10
        self.top = 10
        self.width = 640
        self.height = 480
        self.initUI()
    
    def center(self):
        # geometry of the main window
        qRect = self.frameGeometry()
        # center point of screen
        centerPoint = QDesktopWidget().availableGeometry().center()
        # move rectangle's center point to screen's center point
        qRect.moveCenter(centerPoint)
        # top left of rectangle becomes top left of window centering it
        self.move(qRect.topLeft())

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.center()
    
    def getExistingDirectoryDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        directory= QFileDialog.getExistingDirectory(self,"Seleccionar Carpeta", "", options=options)
        return directory
    
    def getOpenFileNamesDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        files, _ = QFileDialog.getOpenFileNames(self,"Seleccionar Archivos", "","All Files (*);;Python Files (*.py)", options=options)
        return files
    
    def getJSONFileNamesDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        file, _ = QFileDialog.getOpenFileName(self,"Seleccionar JSON", "","JSON Files (*.json)", options=options)
        
        return file
