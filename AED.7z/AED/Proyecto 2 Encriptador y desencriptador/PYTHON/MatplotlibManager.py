#-*- coding: utf-8 -*-
import networkx as nx
import matplotlib.pyplot as plt
from Graph import Graph
from itertools import count
from KilobyteManager import KilobyteManager

class MatplotlibManager:
    def __init__(self):
        self.km=KilobyteManager()

    def printGraph(self,dictionary):

        plt.figure(figsize=(10,6))

        G=nx.DiGraph()

        if not isinstance(dictionary,dict):
            return False
        edgesList={}
        for k,v in dictionary.items():   
            G.add_node(k,group=group)
            for n in v['edges'].items():
                if n:
                    G.add_edges_from([(k,n)])

        #crear una lista de todos los grupos asignandoles un numero para usar colormap de matplotlib 
        #obtiene los grupos del grafo
        groups = set(nx.get_node_attributes(G,'group').values())
        #crea un diccionario con una lista de colores asignados para cada grupo
        mapping = dict(zip(sorted(groups),count()))
        #crea la lista de nodos
        nodes = G.nodes()
        #crea la lista de colores  
        colors = [mapping[G.nodes[n]['group']] for n in nodes]

        #dibuja el grafo
        pos = nx.spring_layout(G)
        nx.draw_networkx(G,pos, node_size=8000, node_shape='o',nodelist=nodes,edgecolors='gray',cmap=plt.cm.tab20 ,linewidths=2,width=2, node_color=colors,with_labels=True, font_color="black") 
        nx.draw_networkx_edge_labels(G,pos,edge_labels=edgesList,font_color='black')
        
        #elimina las medidas
        plt.axis('off')
        #muestra el grafo
        plt.show()







        
        