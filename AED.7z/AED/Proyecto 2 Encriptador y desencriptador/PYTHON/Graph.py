#-*- coding: utf-8 -*-

class Graph:

    def __init__(self):
        self.graph = {}
    
    def addVertex(self,vertexName = None,vtype=None,size=None,path=None):
        if vertexName == None or vtype== None or size == None or size < 0:
            return False

        if (not ("%s".strip() % vertexName) in list(self.graph.keys())) or (("%s".strip() % vertexName) in list(self.graph.keys()) and self.graph["%s".strip() % vertexName]['path']!=path):
            self.graph["%s".strip() % vertexName] = {'edges':{},'vtype':'%s'.strip() %vtype,'size':size,'path':path}
            return True
        

    def addEdges(self,vertexNameOrigin = None, vertexNameDestination = None,weight = 1):
        if not vertexNameOrigin or not vertexNameDestination:
            return False

        weight= self.graph[vertexNameDestination]['size']

        if not ("%s".strip() % vertexNameDestination) in list(self.graph["%s".strip() % vertexNameOrigin]['edges'].keys()):
            self.graph["%s".strip() % vertexNameOrigin]['edges']["%s".strip() % vertexNameDestination]={"weight":weight}
            count=0
            for vertex in self.graph[vertexNameOrigin]['edges'].keys():
                count += self.graph[vertexNameOrigin]['edges'][vertex]['weight']
            self.updateVertex(vertexNameOrigin,vertexNameOrigin,count)

    def relatedTo(self, vertexName = None ):
        if not vertexName: return None 
        g, result = self.graph, {}

        for k,v in g.items():
            if ("%s".strip() % k) == ("%s".strip() % vertexName):
                for edge, weight in v['edges'].items():
                    result["%s".strip() % edge] = None
            elif ("%s".strip() %vertexName) in list(v['edges'].keys()):
                result["%s".strip() % k] = None
        return list(result.keys())

    def updateVertex(self,oldVertexName,newVertexName,size):
        related=self.relatedTo(oldVertexName)
        self.updateName(oldVertexName,newVertexName)
        if self.graph[newVertexName]['vtype']=='file':
            self.updateSize(newVertexName,size)
        if related:
            for item in related:
                if item in list(self.graph[newVertexName]['edges'].keys()):
                    continue
                else:
                    self.updateEdges(item,oldVertexName,newVertexName)
                    self.updateEdgeWeight(item,newVertexName,size)
        
    def updateSize(self,vertexName,size):
        self.graph[vertexName]['size']+=size
        return True
 
    def updateEdgeWeight(self,edgeVertex,vertexName,size):
        self.graph[edgeVertex]['edges'][vertexName]['weight']+=size
        count=0
        for vertex in self.graph[edgeVertex]['edges'].keys():
            count += self.graph[edgeVertex]['edges'][vertex]['weight']
        self.graph[edgeVertex]['size']=count
        related=self.relatedTo(edgeVertex)
        for item in related:
            if item in list(self.graph[edgeVertex]['edges'].keys()):
                continue
            else:
                self.updateEdgeWeight(item,edgeVertex,count)
        return True
         
    def updateName(self,oldVertexName,newVertexName):
        self.graph[newVertexName]=self.graph.pop(oldVertexName)
        return True

    def updateEdges(self,edgeVertex,oldVertexName,newVertexName):
        if oldVertexName in list(self.graph[edgeVertex]['edges'].keys()):
            self.graph[edgeVertex]['edges'][newVertexName]=self.graph[edgeVertex]['edges'].pop(oldVertexName)
            return True
        return False

    def __str__(self):
        result = []
        g = self.graph
        for k,v in g.items():
            for edge, weight  in v['edges'].items():
                result.append("El vertice %s tiene una arista con el vertice %s,  con el peso %s" % (k,edge,weight))
        return "\n".join(result)

    def getGraph(self):
        return self.graph if self.graph else False  
