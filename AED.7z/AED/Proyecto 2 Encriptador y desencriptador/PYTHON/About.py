# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'About.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_About(object):
    def setupUi(self, AcercaDe):
        AcercaDe.setObjectName("AcercaDe")
        AcercaDe.resize(430, 160)
        self.label = QtWidgets.QLabel(AcercaDe)
        self.label.setGeometry(QtCore.QRect(20, 80, 400, 14))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_5 = QtWidgets.QLabel(AcercaDe)
        self.label_5.setGeometry(QtCore.QRect(20, 40, 80, 28))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(10)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(AcercaDe)
        self.label_6.setGeometry(QtCore.QRect(293, 50, 60, 14))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(10)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.label_2 = QtWidgets.QLabel(AcercaDe)
        self.label_2.setGeometry(QtCore.QRect(20, 105, 400, 14))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_4 = QtWidgets.QLabel(AcercaDe)
        self.label_4.setEnabled(True)
        self.label_4.setGeometry(QtCore.QRect(20, 130, 400, 14))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(10)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_7 = QtWidgets.QLabel(AcercaDe)
        self.label_7.setGeometry(QtCore.QRect(40, 10, 400, 21))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(11)
        self.label_7.setFont(font)
        self.label_7.setObjectName("label_7")

        self.retranslateUi(AcercaDe)
        QtCore.QMetaObject.connectSlotsByName(AcercaDe)
        

    def retranslateUi(self, AcercaDe):
        _translate = QtCore.QCoreApplication.translate
        AcercaDe.setWindowTitle(_translate("AcercaDe", "Acerca De"))
        self.label.setText(_translate("AcercaDe", "Orlando Escobar Campos_________________20171003027"))
        self.label_5.setText(_translate("AcercaDe", "Creado por:\nNombre"))
        self.label_6.setText(_translate("AcercaDe", "Cuenta"))
        self.label_2.setText(_translate("AcercaDe", "Billy Enrique Herculano Madrid___________20181001918"))
        self.label_4.setText(_translate("AcercaDe", "Jerry David Martinez Ruiz_________________20181002764"))
        self.label_7.setText(_translate("AcercaDe", "Proyecto De Algoritmos Y Estructura De Datos"))


