# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'progressBar.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from EncryptorManager import EncryptorManager

class Ui_ProgressBarWindow(object):
    


    def setupUi(self, ProgressBarWindow):
        self.EM=EncryptorManager()

        ProgressBarWindow.setObjectName("ProgressBarWindow")
        ProgressBarWindow.resize(400, 100)
        ProgressBarWindow.setStyleSheet("background-color: rgb(238, 238, 236);")
        self.centralwidget = QtWidgets.QWidget(ProgressBarWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.progressBar = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setGeometry(QtCore.QRect(20, 20, 360, 40))
        self.progressBar.setStyleSheet("")
        self.progressBar.setProperty("value", 52)
        self.progressBar.setTextVisible(True)
        self.progressBar.setOrientation(QtCore.Qt.Horizontal)
        self.progressBar.setInvertedAppearance(False)
        self.progressBar.setObjectName("progressBar")
        self.actionDescription = QtWidgets.QLabel(self.centralwidget)
        self.actionDescription.setGeometry(QtCore.QRect(25, 70, 300, 20))
        self.actionDescription.setStyleSheet("")
        self.actionDescription.setObjectName("actionDescription")
        ProgressBarWindow.setCentralWidget(self.centralwidget)
        self.retranslateUi(ProgressBarWindow)
        QtCore.QMetaObject.connectSlotsByName(ProgressBarWindow)
        ProgressBarWindow.show()
        


    def retranslateUi(self, ProgressBarWindow):
        _translate = QtCore.QCoreApplication.translate
        ProgressBarWindow.setWindowTitle(_translate("ProgressBarWindow", "Progreso"))
        self.actionDescription.setText(_translate("ProgressBarWindow", "Accion"))

