# -*- coding = utf-8 -*-
class encryptAlgorithm:
    def __init__(self):
        pass
 
    def encrypt(self, password, byteArray):
        #crea un arreglo con 'password' alargandolo o acortandolo hasta el largo de 'byteArray' 
        #e.g.: password = '1234'  byteArray = b'123456789'   el largo de byteArray es 9 entonces 
        #innerPassword = ['1','2','3','4','1','2','3','4','1'], 
        #si byteArray= b'ab' entonces innerPassword = ['1', '2']   
        ps=sum(ord(i) for i in password)
        innerPassword= [password[i%len(password)] for i in range(len(byteArray))]
    
        #aplica XOR a los bytes de byteArray con los bytes de los elementos en innerPassword
        step2= list(map(lambda a,b: a^ord(b), byteArray,innerPassword))

        #reordena los elementos en el arreglo 'step2' corriendolos segun el entero resultante de la suma de los bytes que contiene password, esto se hace por si password es mas grande que byteArray entonces los elementos de password que esten en posiciones mayores al largo de byteArray aun afecten a la encriptacion
        step3=self.reorder(step2,int(ps//1000))
        
        #aplica XOR a los bytes de byteArray con los bytes de los elementos en innerPassword pero desplazando el valor del byte en 2  e.g.: 100 que es 4 seria 001 que es 1
        step4= list(map(lambda a,b: a^(ord(b)>>2), step3,innerPassword))
        
        #reordena los elementos en el arreglo 'step2' corriendolos segun el entero resultante de la suma de los bytes que contiene password,multiplicados por el negativo del entero que representa al byte del caracter pasword[0] ; esto se hace por si password es mas grande que byteArray entonces los elementos de password que esten en posiciones mayores al largo de byteArray aun afecten a la encriptacion
        step5=self.reorder(step4,-ord(password[0])*int(ps//1000))
        
        #se unen toddos los enteros(que representan bytes) del arreglo step5 para ser retornados en formato de bytes
        return bytes(step5)
        
    
    #en decrypt se aplican los pasos de encrypt al contrario
    def decrypt(self,password,byteArray):
        #crea un arreglo con 'password' alargandolo o acortandolo hasta el largo de 'byteArray' 
        #e.g.: password = '1234'  byteArray = b'123456789'   el largo de byteArray es 9 entonces 
        #innerPassword = ['1','2','3','4','1','2','3','4','1'], 
        #si byteArray= b'ab' entonces innerPassword = ['1', '2']   
        innerPassword= [password[i%len(password)] for i in range(len(byteArray))]
        ps=sum(ord(i) for i in password) 
        #reordena los elementos en el arreglo 'step2' corriendolos segun el entero resultante de la suma de los bytes que contiene password,multiplicados por el entero que representa al byte del caracter pasword[0] ; esto se hace por si password es mas grande que byteArray entonces los elementos de password que esten en posiciones mayores al largo de byteArray aun afecten a la encriptacion
        step5=self.reorder(byteArray,ord(password[0])*int(ps//1000))
        
        #aplica XOR a los bytes de byteArray con los bytes de los elementos en innerPassword pero desplazando el valor del byte en 2  e.g.: 100 que es 4 seria 001 que es 1
        step4= list(map(lambda a,b: a^(ord(b)>>2), step5,innerPassword))
        
        #reordena los elementos en el arreglo 'step2' corriendolos segun el negativo del entero resultante de la suma de los bytes que contiene password, esto se hace por si password es mas grande que byteArray entonces los elementos de password que esten en posiciones mayores al largo de byteArray aun afecten a la encriptacion
        step3=self.reorder(step4,-1*int(ps//1000))
        
        #aplica XOR a los bytes de byteArray con los bytes de los elementos en innerPassword
        step2= list(map(lambda a,b: a^ord(b), step3,innerPassword))
        
        #se unen toddos los enteros(que representan bytes) del arreglo step5 para ser retornados en formato de bytes
        return bytes(step2)

    def reorder(self,array, value):
        #reordena los elementos de un arreglo desplazando los elementos segun un valor
        #e.g.:[1,2,3,4] por el valor de 6 = [3,4,1,2] 
        #si el valor recibido es negativo entonces los corre de forma inversa
        #e.g.:[3,4,1,2] por el valor de -2 = [1,2,3,4] 

        #si value>10 entonces haremos que el rango este entre 0-7 
        if value >10 :
            value = value % 7
         
        for k in range(abs(value)):
            newArray = [array[(k+1)%len(array)] for k in range(len(array))] if value > 0 else [array[(i-1)%len(array)] for i in range(len(array))]
            array=newArray
        return array