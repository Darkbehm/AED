#-*- coding utf-8 -*-
import hashlib, os, os.path, math
from Crypto import Random
from Crypto.Cipher import AES
from time import time 
from os.path import getsize

class AESEncryptor:
    def __init__(self):
        self.time=time
        self.IVSize = 16    # 128 bits para AES
        self.keySize = 32   # esto para hacer que sea de 256 bits la encriptacion
        self.saltSize = 16  # este tamaño es arbitrario

    def pad(self, s):
        return s + b"\0" * (AES.block_size - len(s) % AES.block_size)

    def encrypt(self, message, key):
        message = self.pad(message)
        
        salt = os.urandom(self.saltSize)
        
        derived = hashlib.pbkdf2_hmac('sha256', key, salt, 100000, dklen=self.IVSize + self.keySize)
        iv = derived[0:self.IVSize]
        key = derived[self.IVSize:]
        
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        return salt + cipher.encrypt(message)
        
    def decrypt(self, ciphertext, key):
        salt = ciphertext[0:self.saltSize]
        
        derived = hashlib.pbkdf2_hmac('sha256', key, salt, 100000,
                                    dklen=self.IVSize+self.keySize)
        iv = derived[0:self.IVSize]
        key = derived[self.IVSize:]
 
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        plaintext = cipher.decrypt(ciphertext[self.saltSize:])
        
        return plaintext.rstrip(b"\0")

    def encryptFile(self, originRoute,key,destinationRoute):
        with open(originRoute, 'rb') as fo:
            plaintext = fo.read()
            fo.close()
        enc = self.encrypt(plaintext, key.encode())
        if '/' in originRoute:
            nameArray = originRoute.split('/')
            name = nameArray[-1]
        else:
            name = originRoute 
        with open(destinationRoute + '/' + name + ".enc" , 'wb') as fo:
            fo.write(enc)
            fo.close()
        size= getsize(originRoute)/1000
        
        return {"name":name,"size":size}
        

    def decryptFile(self, originRoute,key,destinationRoute):
        itime = self.time()
        with open(originRoute, 'rb') as fo:
            ciphertext = fo.read()
            fo.close()
        dec = self.decrypt(ciphertext, key.encode())
        if '/' in originRoute:
            nameArray = originRoute.split('/')
            name = nameArray[-1]
        else:
            name = originRoute 
        with open(destinationRoute + "/" + name[:-4], 'wb') as fo:
            fo.write(dec)
            fo.close()
        size= getsize(originRoute)/1000
        ftime=self.time()
        time=ftime-itime
        return {"name":name,"time":time,"size":size}