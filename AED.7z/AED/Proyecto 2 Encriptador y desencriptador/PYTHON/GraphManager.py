#-*- coding: utf-8 -*-
from Graph import Graph

class GraphManager:
    def __init__(self):
        pass
    
    def compareExt(self,ext,name):
        return True if ext == name.split('\n')[0] else False

    def comparePath(self,path1,path2):
        if isinstance(path1,str):
            path1= path1.split('/')
        if isinstance(path2,str):
            path2= path2.split('/')
        if isinstance(path1,list) and isinstance(path2,list):
            if len(path1)== len(path2):
                for i in range(len(path1)):
                    if not path1[i] ==path2[i]:
                        return False
                return True
            else: return False 

    def updateExt(self,oldExt):
        new=oldExt.split('\n')
        nq=int(new[1])+1
        return new[0]+'\n'+str(nq)

    def addFileVertex(self,graph,filePath,vtype,size):
        if vtype=='dir':
            return False

        ext=self.getExtension(filePath)     
        g=graph.getGraph()

        if g:
            for i in g.keys():
                if self.compareExt(ext,i) and vtype == g[i]['vtype'] and self.comparePath(self.getPath(filePath),g[i]['path']):
                    graph.updateVertex(i,self.updateExt(i),size)
                    return True
            graph.addVertex(self.getNameExt(ext),vtype,size,self.getPath(filePath))
        else:
            graph.addVertex(self.getNameExt(ext),vtype,size,self.getPath(filePath))
            return True

    def getExtension(self,filePath):
        fileName = filePath.split('/')[-1]
        fileExt = fileName.split('.')[-1]
        return fileExt

    def getNameExt(self,ext):
        return ext+'\n'+str(1)

    def getNameFromPath(self,path):
        return path.split('/')[-1]
    
    def getPath(self,path):
        return path.split('/')[0:-1]

    def addDirVertex(self,graph,filePath,vtype,size=0):
        if vtype=='file':
            return False

        path=self.getNameFromPath(filePath)          
        g=graph.getGraph()

        if g:
            for i in g.keys():
                if self.compareExt(path,i) and vtype == g[i]['vtype'] and self.comparePath(self.getPath(filePath),g[i]['path']):
                    graph.updateVertex(i,path,size)
                    return True
            graph.addVertex(path,vtype,size,self.getPath(filePath))
        else:
            graph.addVertex(path,vtype,size,self.getPath(filePath))
            return True

    def addEdge(self,graph,origin,destination,dType):
        g=graph.getGraph()
        origin = self.getNameFromPath(origin)
        path=self.getPath(destination)
        destination = self.getNameFromPath(destination) if dType == 'dir' else self.getExtension(destination)
        
        for i in g.keys():
            if self.compareExt(destination,i) and dType == g[i]['vtype'] and self.comparePath(path,g[i]['path']):
                graph.addEdges(origin,i)
                return True


