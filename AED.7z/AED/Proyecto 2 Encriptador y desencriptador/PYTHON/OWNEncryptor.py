#-*- coding = utf-8 -*-
from OWNAlgorithm import  encryptAlgorithm
from time import time
from os.path import getsize
class OWNEncryptor:
    def __init__(self):
        self.time=time
        self.e= encryptAlgorithm()
    
    def encrypt(self, message, key):
        if isinstance(message,str):
            message=bytearray(message,'utf-8')
        return self.e.encrypt(key,message)
        
    def decrypt(self, ciphertext, key):
        if isinstance(ciphertext,str):
            message=bytearray(ciphertext,'utf-8')
        return self.e.decrypt(key,ciphertext)

    def encryptFile(self, originRoute,key,destinationRoute):
        with open(originRoute, 'rb') as fo:
            plaintext = fo.read()
            fo.close()
        enc = self.encrypt(plaintext, key)
        if '/' in originRoute:
            nameArray = originRoute.split('/')
            name = nameArray[-1]
        else:
            name = originRoute 
        with open(destinationRoute + '/' + name + ".objenc" , 'wb') as fo:
            fo.write(enc)
            fo.close()
        

    def decryptFile(self, originRoute,key,destinationRoute):
        itime=self.time()
        with open(originRoute, 'rb') as fo:
            ciphertext = fo.read()
            fo.close()
        dec = self.decrypt(ciphertext, key)
        if '/' in originRoute:
            nameArray = originRoute.split('/')
            name = nameArray[-1]
        else:
            name = originRoute 
        with open(destinationRoute + "/" + name[:-7], 'wb') as fo:
            fo.write(dec)
            fo.close()

        size= getsize(originRoute)/1000
        ftime=self.time()
        time=ftime-itime
        return {"name":name,"time":time,"size":size}
