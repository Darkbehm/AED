class TimeManager: 
  
  def __init__(self):
    pass

  def timeToString(self, seconds = 0):    
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)

    if minutes == 1:
      return "%s minuto %s segundos" % (minutes, seconds)
    else:
      return "%s minutos %s segundos" % (minutes, seconds)

  def time(self, seconds = 0):
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)

    if seconds < 10:
      return "%s:0%s" % (minutes, seconds)
    else:
      return "%s:%s" % (minutes, seconds)
