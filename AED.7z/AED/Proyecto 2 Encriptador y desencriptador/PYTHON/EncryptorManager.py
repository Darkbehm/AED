#-*- coding utf-8 -*-
from AESEncryptor import AESEncryptor
from OWNEncryptor import OWNEncryptor
from FileManager import FileManager
from time import time
from os.path import getsize
from GraphManager import GraphManager
from Graph import Graph


class EncryptorManager:
    def __init__(self):
        self.AESEnc = AESEncryptor()
        self.OWNEnc = OWNEncryptor()
        self.fm = FileManager()
        self.gm=GraphManager()
        self.graph=Graph()
        self.totalSize=0
        self.quantity=0
        self.archiveDict={}

    #encripta varios archivos dados por un arreglo de sus nombres
    def encryptFiles(self, originFileArray, key, destinationRoute):
        initialTime = time()
        self.fm.makeEncryptFileDirectorie(destinationRoute)
        count=0
        path=''
        for originFile in originFileArray:
            if count==0:
                count=1
                path=originFile.split('/')[0:-1]
                path='/'.join(path)
                self.gm.addDirVertex(self.graph,path,'dir')
            itime=time()
            currentArchive=self.AESEnc.encryptFile(originFile,key,destinationRoute+'/AES_256')
            self.OWNEnc.encryptFile(originFile,key,destinationRoute+'/OWNAlgorithm')
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.gm.addFileVertex(self.graph,originFile,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,path,originFile,'file')
            ftime=time()
            tTime=ftime-itime
            currentArchive['time']=tTime
            self.archiveDict["%s"%(self.quantity)]= currentArchive
        

        finalTime=time()
        totalTime=finalTime-initialTime
        
        #r=diccionario que se usa para crear el log.html
        r={
            "process":"Encriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #desencripta varios archivos dados por un arreglo de sus nombres
    def decryptFiles(self, originFileArray, key, destinationRout):
        initialTime = time()
        self.fm.makeDecryptFileDirectorie(destinationRoute)
        count=0
        for originFile in originFileArray:    
            if count==0:
                    count=1
                    path=originFile.split('/')[0:-1]
                    path='/'.join(path)
                    self.gm.addDirVertex(self.graph,path,'dir')
            if originFile.endswith('.enc'):
                currentArchive=self.AESEnc.decryptFile(originFile,key,destinationRoute+'/DESC_AES_256')
            elif originFile.endswith('.objenc'):
                currentArchive=self.OWNEnc.decryptFile(originFile,key,destinationRoute+'/DESC_OWNAlgorithm')
            else:
                continue
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.archiveDict["%s"%(self.quantity)]= currentArchive
            self.gm.addFileVertex(self.graph,originFile,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,path,originFile,'file')
        finalTime=time()
        totalTime=finalTime-initialTime
        #r=diccionario que se usa para crear el log.html de la encriptacion AES256
        r={
            "process":"Desencriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #encripta archivo individual
    def encryptFile(self, originFile, key, destinationRoute):
        initialTime = time()
        self.fm.makeEncryptFileDirectorie(destinationRoute)
      
        path=originFile.split('/')[0:-1]
        path='/'.join(path)
        self.gm.addDirVertex(self.graph,path,'dir')

        currentInitialTime= time()
        currentArchive=self.AESEnc.encryptFile(originFile,key,destinationRoute+'/AES_256')
        self.OWNEnc.encryptFile(originFile,key,destinationRoute+'/OWNAlgorithm')
        currentFinalTime= time()
        currentTime=currentFinalTime-currentInitialTime
        currentArchive['time']=currentTime
        self.quantity+=1
        self.totalSize+= currentArchive["size"]
        self.archiveDict["%s"%(self.quantity)]= currentArchive

        self.gm.addFileVertex(self.graph,originFile,'file',currentArchive["size"])
        self.gm.addEdge(self.graph,path,originFile,'file')

        finalTime=time()
        totalTime=finalTime-initialTime
        #r=diccionario que se usa para crear el log.html
        r={
            "process":"Encriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #desencripta archivo individual
    def decryptFile(self, originFile, key, destinationRoute):
        initialTime = time()
        self.fm.makeDecryptFileDirectorie(destinationRoute)

        path=originFile.split('/')[0:-1]
        path='/'.join(path)
        self.gm.addDirVertex(self.graph,path,'dir')

        if originFile.endswith('.enc'):
            currentArchive=self.AESEnc.decryptFile(originFile,key,destinationRoute+'/DESC_AES_256')
        elif originFile.endswith('.objenc'):
            currentArchive=self.OWNEnc.decryptFile(originFile,key,destinationRoute+'/DESC_OWNAlgorithm')
        else:
            return False
        self.quantity+=1
        self.totalSize+= currentArchive["size"]
        self.archiveDict["%s"%(self.quantity)]= currentArchive

        self.gm.addFileVertex(self.graph,originFile,'file',currentArchive["size"])
        self.gm.addEdge(self.graph,path,originFile,'file')

        finalTime=time()
        totalTime=finalTime-initialTime
        #r=diccionario que se usa para crear el log.html de la encriptacion AES256
        r={
            "process":"Desencriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #encripta toda una carpeta 
    def encryptDirectorie(self, originRoute, key, destinationRoute):
        initialTime=time()
        self.fm.makeEncryptDirectorie(originRoute,destinationRoute)
        self.gm.addDirVertex(self.graph,originRoute,'dir')
        for archive in self.fm.getArchive(originRoute):
            currentInitialTime=time()
            currentArchive=self.AESEnc.encryptFile(originRoute+'/'+archive,key,destinationRoute+'/AES_256')
            self.OWNEnc.encryptFile(originRoute+'/'+archive,key,destinationRoute+'/OWNAlgorithm')
            currentFinalTime= time()
            
            currentTime=currentFinalTime-currentInitialTime
            currentArchive['time']=currentTime
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.archiveDict["%s"%(self.quantity)]= currentArchive
            self.gm.addFileVertex(self.graph,originRoute+'/'+archive,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,originRoute,originRoute+'/'+archive,'file')

        for directory in self.fm.getDirectorieList(originRoute):
            self.encryptDirectorieInner(originRoute+'/'+directory,key,destinationRoute+'/AES_256/'+directory,destinationRoute+'/OWNAlgorithm/'+directory)
        finalTime=time()
        totalTime=finalTime-initialTime
        #r=diccionario que se usa para crear el log.html
        r={
            "process":"Encriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #encripta todas las subcarpetas que contiene la carpeta de origende la funcion enncryptDirectorie
    def encryptDirectorieInner(self,originRoute,key,destinationRouteAES,destinationRouteOWNAlgorithm):
        parentpath=originRoute.split('/')[0:-1]
        parentpath='/'.join(parentpath)
        self.gm.addDirVertex(self.graph,originRoute,'dir')
        self.gm.addEdge(self.graph,parentpath,originRoute,'dir')
        for archive in self.fm.getArchive(originRoute):
            currentInitialTime=time()
            currentArchive=self.AESEnc.encryptFile(originRoute+'/'+archive,key,destinationRouteAES)
            self.OWNEnc.encryptFile(originRoute+'/'+archive,key,destinationRouteOWNAlgorithm)
            currentFinalTime= time()
            currentTime=currentFinalTime-currentInitialTime
            currentArchive['time']=currentTime
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.archiveDict["%s"%(self.quantity)]= currentArchive
            self.gm.addFileVertex(self.graph,originRoute+'/'+archive,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,originRoute,originRoute+'/'+archive,'file')
            
        for directory in self.fm.getDirectorieList(originRoute):
            self.encryptDirectorieInner(originRoute+'/'+directory,key,destinationRouteAES+'/'+directory,destinationRouteOWNAlgorithm+'/'+directory)

    #desencripta toda una carpeta 
    def decryptDirectorie(self, originRoute, key, destinationRoute):
        initialTime=time()
        self.fm.makeDecryptDirectorie(originRoute,destinationRoute)
        self.gm.addDirVertex(self.graph,originRoute,'dir')
        for archive in self.fm.getArchive(originRoute):
            if archive.endswith('.enc'):
                currentArchive=self.AESEnc.decryptFile(originRoute+'/'+archive,key,destinationRoute+'/DESC_AES_256')
            elif archive.endswith('.objenc'):
                currentArchive=self.OWNEnc.decryptFile(originRoute+'/'+archive,key,destinationRoute+'/DESC_OWNAlgorithm')
            else:
                continue
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.archiveDict["%s"%(self.quantity)]= currentArchive
            self.gm.addFileVertex(self.graph,originRoute+'/'+archive,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,originRoute,originRoute+'/'+archive,'file')
        for directory in self.fm.getDirectorieList(originRoute):
            self.decryptDirectorieInner(originRoute+'/'+directory,key,destinationRoute+'/DESC_AES_256/'+directory,destinationRoute+'/DESC_OWNAlgorithm/'+directory)
        finalTime=time()
        totalTime=finalTime-initialTime
        #r=diccionario que se usa para crear el log.html de la encriptacion AES256
        r={
            "process":"Desencriptado",
            "quantity": self.quantity,
            "totalTime":totalTime,
            "totalSize":self.totalSize,
            "archive":self.archiveDict
        }
        graph=self.graph.getGraph()
        #self.__init__() reestablece los valores por defecto de totaSize y quantity
        self.__init__()
        return [r,graph]

    #desencripta todas las subcarpetas que contiene la carpeta de origende la funcion enncryptDirectorie
    def decryptDirectorieInner(self,originRoute,key,destinationRouteAES,destinationRouteOWNAlgorithm):
        parentpath=originRoute.split('/')[0:-1]
        parentpath='/'.join(parentpath)
        self.gm.addDirVertex(self.graph,originRoute,'dir')
        self.gm.addEdge(self.graph,parentpath,originRoute,'dir')
        for archive in self.fm.getArchive(originRoute):
            if archive.endswith('.enc'):
                currentArchive=self.AESEnc.decryptFile(originRoute+'/'+archive,key,destinationRouteAES)
            elif archive.endswith('.objenc'):
                currentArchive=self.OWNEnc.decryptFile(originRoute+'/'+archive,key,destinationRouteOWNAlgorithm)
            else:
                continue
            self.quantity+=1
            self.totalSize+= currentArchive["size"]
            self.archiveDict["%s"%(self.quantity)]= currentArchive
            self.gm.addFileVertex(self.graph,originRoute+'/'+archive,'file',currentArchive["size"])
            self.gm.addEdge(self.graph,originRoute,originRoute+'/'+archive,'file')
        for directory in self.fm.getDirectorieList(originRoute):
            self.decryptDirectorieInner(originRoute+'/'+directory,key,destinationRouteAES+'/'+directory,destinationRouteOWNAlgorithm+'/'+directory)
