# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Table(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(414, 189)
        Dialog.setMaximumSize(414, 189)
        Dialog.setMinimumSize(414, 189)
        self.Table = QtWidgets.QTextBrowser(Dialog)
        self.Table.setGeometry(QtCore.QRect(0, 0, 414, 189))
        self.Table.setObjectName("Table")
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "LOG"))
