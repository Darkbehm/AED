# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'OpenFile.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog, QDesktopWidget
from PyQt5.QtGui import QIcon


class Ui_FileDirectorieDialog(object):
    def center(self):
        # geometry of the main window
        qRect = self.frameGeometry()
        # center point of screen
        centerPoint = QDesktopWidget().availableGeometry().center()
        # move rectangle's center point to screen's center point
        qRect.moveCenter(centerPoint)
        # top left of rectangle becomes top left of window centering it
        self.move(qRect.topLeft())


    def openFile(self):
        path = self.main.openFileUi.getOpenFileNamesDialog()
        if len(path)==1:
            self.main.plainTextEdit.setPlainText(path[0])
            self.main.encryptIndicator=1
        elif len(path)>1:
            path= '\n'.join(path)
            self.main.plainTextEdit.setPlainText(path)
            self.main.encryptIndicator=2
        else:
            pass
        self.dialog.close()

    def openDirectorie(self):
        path = self.main.openFileUi.getExistingDirectoryDialog()
        if path:
            self.main.plainTextEdit.setPlainText(path)
            self.main.encryptIndicator=3        
        self.dialog.close()
        
    def openGraph(self):
        path = self.main.openFileUi.getJSONFileNamesDialog()
        if path:
            self.main.plainTextEdit.setPlainText(path)
        self.dialog.close() 

        
    def setupUi(self, FileDirectorieDialog,main):
        self.main=main
        
        FileDirectorieDialog.setObjectName("FileDirectorieDialog")
        FileDirectorieDialog.resize(400, 200)
        FileDirectorieDialog.setMaximumSize(400, 200)
        FileDirectorieDialog.setMinimumSize(400, 200)
        FileDirectorieDialog.setStyleSheet("background-color: rgb(238, 238, 236);")
        self.move=FileDirectorieDialog.move
        self.frameGeometry=FileDirectorieDialog.frameGeometry
        self.center()

        self.dialog=FileDirectorieDialog
        self.btnSelectFile = QtWidgets.QPushButton(FileDirectorieDialog)
        self.btnSelectFile.setEnabled(True)
        self.btnSelectFile.setGeometry(QtCore.QRect(40, 40, 150, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnSelectFile.setFont(font)
        self.btnSelectFile.setMouseTracking(False)
        self.btnSelectFile.setStyleSheet("background-color: rgb(53, 53, 53);\n"
                                        "color: rgb(255, 255, 255);\n"
                                        )
        self.btnSelectFile.setCheckable(False)
        self.btnSelectFile.setChecked(False)
        self.btnSelectFile.setAutoDefault(False)
        self.btnSelectFile.setDefault(False)
        self.btnSelectFile.setFlat(False)
        self.btnSelectFile.setObjectName("btnSelectFile")
        self.btnSelectFile.clicked.connect(self.openFile)

        self.btnSelectDirectorie = QtWidgets.QPushButton(FileDirectorieDialog)
        self.btnSelectDirectorie.setEnabled(True)
        self.btnSelectDirectorie.setGeometry(QtCore.QRect(210, 40, 150, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnSelectDirectorie.setFont(font)
        self.btnSelectDirectorie.setMouseTracking(False)
        self.btnSelectDirectorie.setStyleSheet("background-color: rgb(53, 53, 53);\n"
                                                "color: rgb(255, 255, 255);\n"
                                                )
        self.btnSelectDirectorie.setCheckable(False)
        self.btnSelectDirectorie.setChecked(False)
        self.btnSelectDirectorie.setAutoDefault(False)
        self.btnSelectDirectorie.setDefault(False)
        self.btnSelectDirectorie.setFlat(False)
        self.btnSelectDirectorie.setObjectName("btnSelectDirectorie")

        self.btnSelectDirectorie.clicked.connect(self.openDirectorie)

        self.labelEncrypt = QtWidgets.QLabel(FileDirectorieDialog)
        self.labelEncrypt.setGeometry(QtCore.QRect(100, 10, 200, 20))
        self.labelEncrypt.setAlignment(QtCore.Qt.AlignCenter)
        self.labelEncrypt.setObjectName("labelEncrypt")
        self.btnSelectJSON = QtWidgets.QPushButton(FileDirectorieDialog)
        self.btnSelectJSON.setEnabled(True)
        self.btnSelectJSON.setGeometry(QtCore.QRect(125, 130, 150, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnSelectJSON.setFont(font)
        self.btnSelectJSON.setMouseTracking(False)
        self.btnSelectJSON.setStyleSheet("background-color: rgb(53, 53, 53);\n"
                                            "color: rgb(255, 255, 255);\n"
                                            )
        self.btnSelectJSON.setCheckable(False)
        self.btnSelectJSON.setChecked(False)
        self.btnSelectJSON.setAutoDefault(False)
        self.btnSelectJSON.setDefault(False)
        self.btnSelectJSON.setFlat(False)
        self.btnSelectJSON.setObjectName("btnSelectJSON")

        self.btnSelectJSON.clicked.connect(self.openGraph)

        self.labelJson = QtWidgets.QLabel(FileDirectorieDialog)
        self.labelJson.setGeometry(QtCore.QRect(100, 100, 200, 20))
        self.labelJson.setAlignment(QtCore.Qt.AlignCenter)
        self.labelJson.setObjectName("labelJson")


        self.retranslateUi(FileDirectorieDialog)
        QtCore.QMetaObject.connectSlotsByName(FileDirectorieDialog)

    def retranslateUi(self, FileDirectorieDialog):
        _translate = QtCore.QCoreApplication.translate
        FileDirectorieDialog.setWindowTitle(_translate("FileDirectorieDialog", "Abrir Archivo"))
        self.btnSelectFile.setText(_translate("FileDirectorieDialog", "Archivo"))
        self.btnSelectDirectorie.setText(_translate("FileDirectorieDialog", "Carpeta"))
        self.labelEncrypt.setText(_translate("FileDirectorieDialog", "Encriptar o Desencriptar"))
        self.btnSelectJSON.setText(_translate("FileDirectorieDialog", "Grafo"))
        self.labelJson.setText(_translate("FileDirectorieDialog", "Abrir JSON/Grafo"))

