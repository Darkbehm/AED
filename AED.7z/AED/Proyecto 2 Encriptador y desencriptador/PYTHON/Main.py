# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MainWindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog, QDesktopWidget
from PyQt5.QtGui import QIcon
from OpenFileWindow import Ui_FileDirectorieDialog
from OpenFileDialogUI import Ui_OpenFile
from About import Ui_About
from EncryptorManager import EncryptorManager
from ProgressBarUi import Ui_ProgressBarWindow
from TableHtml import Ui_Table
from TimeManager import TimeManager
from KilobyteManager import KilobyteManager
from MatplotlibManager import MatplotlibManager


class Ui_MainWindow(object):

    def openFileDialog(self):
        self.openFileDialog=QtWidgets.QMainWindow()
        self.uiOpenFileDialog= Ui_FileDirectorieDialog()
        self.uiOpenFileDialog.setupUi(self.openFileDialog,self)
        self.openFileDialog.show()

    def openDestinationDirectory(self):
        path=self.openFileUi.getExistingDirectoryDialog()
        self.decrypt.setPlainText(path)

    def openAbout(self):
        self.about=QtWidgets.QMainWindow()
        self.uiAbout=Ui_About()
        self.uiAbout.setupUi(self.about)
        self.about.show()

    def openProgressBar(self,process):
        self.progressBar=QtWidgets.QMainWindow()
        self.uiProgressBar=Ui_ProgressBarWindow()
        self.uiProgressBar.setupUi(self.progressBar,indicator)

    def center(self):
        qRect = self.frameGeometry()
        centerPoint = QDesktopWidget().availableGeometry().center()
        qRect.moveCenter(centerPoint)
        self.move(qRect.topLeft())

    def encryptAction(self):
        path = self.plainTextEdit.toPlainText()
        key = self.passwordTexEdit.text() if self.passwordTexEdit else None
        destination = self.decrypt.toPlainText()

        if path.count('/') and key and destination.count('/'):
            
            #carpeta completa
            if self.encryptIndicator == 3:
                dictLog = self.EM.encryptDirectorie(path,key,destination)
            
            #varios archivos
            elif self.encryptIndicator == 2:
                files= path.split('\n')
                dictLog=self.EM.encryptFiles(files,key,destination)
            
            #archivo unico
            elif self.encryptIndicator==1:
                dictLog=self.EM.encryptFile(path,key,destination)
            
            self.showTable(dictLog[0],destination)
            self.createJson(dictLog[1],destination)
            self.clearText()
        else:
            #agregar aqui advertencia
            return False
        self.encryptIndicator=0
    
    def clearText(self):
        self.plainTextEdit.setPlainText('')
        self.passwordTexEdit.setText('')
        self.decrypt.setPlainText('')


    def decryptAction(self):
        path = self.plainTextEdit.toPlainText()
        key = self.passwordTexEdit.text() if self.passwordTexEdit else None
        destination = self.decrypt.toPlainText()
        if path.count('/') and key and destination.count('/'):
            if self.encryptIndicator == 3:
                dictLog=self.EM.decryptDirectorie(path,key,destination)
            elif self.encryptIndicator == 2:
                files= path.split('\n')
                for item in files:
                    dictLog=self.EM.decryptFile(item,key,destination)
            elif self.encryptIndicator==1:
                dictLog=self.EM.decryptFile(path,key,destination)
            self.showTable(dictLog[0],destination)
            self.createJson(dictLog[1],destination)
            self.clearText()
        else:
            #agregar aqui advertencia
            return False
        self.encryptIndicator=0

    def createJson(self,JSONDict,destinationRoute):
        self.EM.fm.writeJSON(destinationRoute,JSONDict)
        self.showJson(JSONDict)
    
    def showJson(self,JSONDict):
        if isinstance(JSONDict,str):
            json=self.EM.fm.openJSON(JSONDict)
        else:
            json=JSONDict
        mm=MatplotlibManager()
        mm.printGraph(json)

    def openJSON(self):
        return self.showJson(self.plainTextEdit.toPlainText())
    
    def showTable(self,dictLog,destinationRoute):
        tm = TimeManager()
        kbm = KilobyteManager()

        tableHtml = "<table style=\"border: 1px solid #ddd; border-collapse: collapse; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;\"> <tr style=\"background-color: #b7b7b7; text-align: center;\"><td colspan=\"3\">"
        tableHtml += "Proceso Ejecutado: "
        tableHtml += dictLog["process"]
        tableHtml += '</td></tr><tr style="text-align: center"><td style=\'text-align: right; font-weight: 900\'>Archivos procesados</td><td colspan="2" style="text-align: center">'
        tableHtml += str(dictLog["quantity"])
        tableHtml += '</td></tr><tr><td style=\'text-align: right; font-weight: 900\'>Tiempo</td><td colspan="2" style="text-align: center">'
        tableHtml += tm.timeToString(dictLog["totalTime"])
        tableHtml += '</td></tr><tr><td style=\'text-align: right; font-weight: 900\'>Tamaño Total</td><td colspan="2" style="text-align: center">'
        tableHtml += kbm.kbToString(dictLog["totalSize"])
        tableHtml += '</td></tr><tr style="background-color: #b7b7b7; text-align: center;"><td colspan="3">Archivos Encriptacion</td></tr><tr style="text-align: center"><td>Nombre</td><td>Tiempo</td><td>Tamaño</td></tr>'
            
        for i in range(len(dictLog["archive"])):
            tableHtml += '<tr style="text-align: center">'
            tableHtml += '<td>' + dictLog["archive"][str(i+1)]["name"] + '</td>'
            tableHtml += '<td>' + tm.time(dictLog["archive"][str(i+1)]["time"]) + '</td>'
            tableHtml += '<td>' + kbm.kbToString(dictLog["archive"][str(i+1)]["size"])  + '</td>'
            tableHtml += '</tr>'
        
        tableHtml += '</table>'
        self.EM.fm.writeHTML(destinationRoute,tableHtml)
        self.table=QtWidgets.QMainWindow()
        self.uiTable=Ui_Table()
        self.uiTable.setupUi(self.table)
        self.uiTable.Table.setHtml(tableHtml)
        self.table.show()


    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(640, 480)
        MainWindow.setMaximumSize(640, 480)
        MainWindow.setMinimumSize(640, 480)
        
        self.EM= EncryptorManager()
        self.encryptIndicator=0
        self.move=MainWindow.move
        self.frameGeometry=MainWindow.frameGeometry
        self.center()
        self.openFileUi=Ui_OpenFile()

        MainWindow.setStyleSheet("background-color: rgb(238, 238, 236);")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setEnabled(True)
        self.centralwidget.setObjectName("centralwidget")
       
        self.btnAbout = QtWidgets.QPushButton(self.centralwidget)
        self.btnAbout.setGeometry(QtCore.QRect(220, 20, 200, 40))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnAbout.setFont(font)
        self.btnAbout.setStyleSheet("background-color: rgb(100, 100, 100);\n"
                                                "color: rgb(255, 255, 255);\n"
                                                )
        self.btnAbout.setObjectName("btnAbout")

        self.btnAbout.clicked.connect(self.openAbout)

        self.btnEncrypt = QtWidgets.QPushButton(self.centralwidget)
        self.btnEncrypt.setGeometry(QtCore.QRect(110, 300, 200, 60))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnEncrypt.setFont(font)
        self.btnEncrypt.setStyleSheet("background-color: rgb(114, 19, 63);\n"
                                                "color: rgb(255, 255, 255);\n"
                                                )
        self.btnEncrypt.setObjectName("btnEncrypt")

        self.btnEncrypt.clicked.connect(self.encryptAction)

        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.centralwidget)
        self.plainTextEdit.setGeometry(QtCore.QRect(40, 105, 400, 30))
        self.plainTextEdit.setStyleSheet("background-color: rgb(178, 191, 177);\n"
                                                "border-color: rgb(0,0,0)\n"
                                                "")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(60, 60, 240, 41))
        self.label.setStyleSheet("color:rgb(53, 53, 53);")
        self.label.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        self.label.setObjectName("label")
        self.btnSelectOrigin = QtWidgets.QPushButton(self.centralwidget)
        self.btnSelectOrigin.setEnabled(True)
        self.btnSelectOrigin.setGeometry(QtCore.QRect(450, 95, 150, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnSelectOrigin.setFont(font)
        self.btnSelectOrigin.setMouseTracking(False)
        self.btnSelectOrigin.setStyleSheet("background-color: rgb(53, 53, 53);\n"
                                                "color: rgb(255, 255, 255);\n"
                                                )
        self.btnSelectOrigin.setCheckable(False)
        self.btnSelectOrigin.setChecked(False)
        self.btnSelectOrigin.setAutoDefault(False)
        self.btnSelectOrigin.setDefault(False)
        self.btnSelectOrigin.setFlat(False)
        self.btnSelectOrigin.setObjectName("btnSelectOrigin")

        self.btnSelectOrigin.clicked.connect(self.openFileDialog)

        self.btnShowGraph = QtWidgets.QPushButton(self.centralwidget)
        self.btnShowGraph.setGeometry(QtCore.QRect(220, 380, 200, 60))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnShowGraph.setFont(font)
        self.btnShowGraph.setStyleSheet("background-color:rgb(158, 43, 37);\n"
                                                "color:  rgb(255, 255, 255);\n"
                                                )
        self.btnShowGraph.setObjectName("btnShowGraph")

        self.btnShowGraph.clicked.connect(self.openJSON)

        self.btnDecrypt = QtWidgets.QPushButton(self.centralwidget)
        self.btnDecrypt.setGeometry(QtCore.QRect(330, 300, 200, 60))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnDecrypt.setFont(font)
        self.btnDecrypt.setStyleSheet("background-color: rgb(24, 88, 88);\n"
                                                "color: rgb(255, 255, 255);\n"
                                                )
        self.btnDecrypt.setObjectName("btnDecrypt")
        
        self.btnDecrypt.clicked.connect(self.decryptAction)
        
        self.btnSelectDestination = QtWidgets.QPushButton(self.centralwidget)
        self.btnSelectDestination.setGeometry(QtCore.QRect(450, 165, 150, 50))

        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnSelectDestination.setFont(font)
        self.btnSelectDestination.setStyleSheet("background-color: rgb(53, 53, 53);\n"
                                                        "color: rgb(255, 255, 255);\n"
                                                        )
        self.btnSelectDestination.setObjectName("btnSelectDestination")

        self.btnSelectDestination.clicked.connect(self.openDestinationDirectory)

        self.decrypt = QtWidgets.QPlainTextEdit(self.centralwidget)
        self.decrypt.setGeometry(QtCore.QRect(40, 175, 400, 30))
        self.decrypt.setStyleSheet("background-color: rgb(178, 191, 177);\n"
                                                "border-color: rgb(0,0,0)\n"
                                                "")
        self.decrypt.setObjectName("decrypt")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(60, 155, 240, 16))
        self.label_2.setStyleSheet("color:rgb(53, 53, 53);")
        self.label_2.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        self.label_2.setObjectName("label_2")
        self.passwordTexEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.passwordTexEdit.setGeometry(QtCore.QRect(40, 245, 560, 30))
        self.passwordTexEdit.setStyleSheet("background-color: rgb(178, 191, 177);\n"
                                        "border-color: rgb(0,0,0)\n")
        self.passwordTexEdit.setObjectName("passwordTexEdit")

        self.passwordTexEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(60, 225, 240, 16))
        self.label_3.setStyleSheet("color:rgb(53, 53, 53);")
        self.label_3.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        self.label_3.setObjectName("label_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.label.setBuddy(self.plainTextEdit)
        self.label_2.setBuddy(self.decrypt)
        self.label_3.setBuddy(self.passwordTexEdit)
        
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Encriptador/Desencriptador"))
        self.btnAbout.setText(_translate("MainWindow", "Acerca De"))
        self.btnEncrypt.setText(_translate("MainWindow", "Ejecutar\n"
                                                "Encriptado"))
        self.label.setText(_translate("MainWindow", "Ruta, Archivo o\n"
                                                "Archivos Origen"))
        self.btnSelectOrigin.setText(_translate("MainWindow", "Seleccionar"))
        self.btnShowGraph.setText(_translate("MainWindow", "Mostrar Grafo desde\n"
                                                "archivo JSON"))
        self.btnDecrypt.setText(_translate("MainWindow", "Ejecutar\n"
                                                "Desencriptado"))
        self.btnSelectDestination.setText(_translate("MainWindow", "Seleccionar"))
        self.label_2.setText(_translate("MainWindow", "Ruta Destino"))
        self.label_3.setText(_translate("MainWindow", "Contraseña"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())