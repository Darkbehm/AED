class KilobyteManager:
  def __init__(self):
    pass

  def kbToString(self, kilobyte = 0):
    reversedString = str(int(kilobyte))[::-1]

    kbInString = ""
    for i in range(0, len(reversedString)):
      
      kbInString += reversedString[i]

      if ((i + 1) % 3) == 0 and i != len(reversedString) - 1:
        kbInString += ','

    return ("%sKB" % kbInString[::-1])


