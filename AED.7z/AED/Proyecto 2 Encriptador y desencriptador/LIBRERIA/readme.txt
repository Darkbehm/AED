PROGRAMA DE ENCRIPTADO Y DESENCRIPTADO

el programa utiliza la libreria de python3 pycrypto (https://pypi.org/project/pycrypto/)
para realizar la operacion de encriptado y desencriptado con el algoritmo de AES-256

tambien utiliza las librerias de matplotlib y networkx para la representacion grafica de los grafos

Instalacion de pycrypto:
    Se debe instalar pip3 en linux,
    Se debe instalar pycrypto en Python3 usando Pip3 con el comando
    	    $ pip3 install pycypto

instalacion de matplotlib y networkx
	    $ sudo apt-get install python3-matplotlib
 	    $ pip3 install networkx


-------------------Creditos--------------------------

programa de encriptaddo y desencriptado hecho por:
-Billy Enrique Herculano, 
-Orlando Escobar Campos y 
-Jerry David Martinez

para la clase del Algoritmos y estructuras de datos en la seccion 0900 impartida por el ingeniero
JOSE MANUEL INESTROZA MURILLO


