#-*- coding:utf-8 -*-
from Node import Node
class CircularLinkedList:
    def __init__ (self):
        self.first= None
        self.last= None
        self.length= 0

    def push (self,value,position):
        if not isinstance(position,int) or position<0:
            print("position debe ser mayor o igual que 0")
            return False

        node = Node(value)
        
        # caso cuando el primer nodo no existe aun
        if not self.first:
            self.first= self.last= node
            self.last.next = self.first
            self.first.previous=self.last
            self.length+=1
            return True

        # cuando se quiere ingresar en la primera posicion
        if position == 0:
            queue= self.first
            self.first= node
            self.first.next=queue
            self.last.next = self.first
            self.first.previous=self.last
            self.length +=1
            return True

        # caso general en cualquier posicion
        
        count=0
        current=self.first
        for count in range(self.length):
            if position==count+1:
                queue=current.next
                current.next=node
                current.next.previous=current
                current.next.next=queue
                current.next.next.previous=current.next
                self.length+=1
                return True
            current=current.next

        #lo agregga en la ultima posicion
        last=self.last
        last.next= node
        self.last=last.next
        self.last.previous= last
        self.last.next=self.first
        self.first.previous=self.last
        
        self.length+=1
        return True

    def printFromFirst(self):
        if self.first==None:
            return None
        
        if self.length==1:
            result = "  %s <=> " %self.first.value
            return result   
        result=""
        count=0
        current=self.first
        for count in range(self.length):
            result+= "%s <=> " %current.value
            current=current.next
        return result
    
    def pop (self,position):
        if not isinstance(position,int) or position<0:
            return False

        # elimina y retorna el de la primera posicion
        if position == 0:
            queue=self.first.next
            element= self.first.value
            self.first=queue
            self.last.next=self.first
            self.first.previous=self.last
            self.length-=1 
            return element

        count = 0 
        current = self.first

        #elimina y retorna el de cualquier posicion intermedia

        for count in range(self.length-2):
            if count+1 ==position:
                element=current.next.value
                current.next=current.next.next
                current.next.previous=current
                self.length -=1
                return element     
            current=current.next
        
        #elimina y retorna el ultimo elemento
        element=current.next.value
        current.next=current.next.next
        current.next.previous=current
        self.length -=1
        return element

        


      










ll= CircularLinkedList()
ll.push(1,1)
print(ll.printFromFirst())
ll.push(2,0)
print(ll.printFromFirst())
ll.push(3,9)
print(ll.printFromFirst())
ll.push(4,0)
print(ll.printFromFirst())
ll.push(5,4)
print(ll.printFromFirst())
ll.push(5,0)
print(ll.printFromFirst())
print(ll.pop(1))
print(ll.printFromFirst())
print(ll.pop(1))
print(ll.printFromFirst())