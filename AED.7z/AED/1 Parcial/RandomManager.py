#-*-coding:utf-8-*-
import random

class RandomManager:
    def __init__(self):
        pass
    
    def randomInt(self,min,max):
        r=random.random()
        return int(r*(max-min)+min)

    def randomChar(self):
        alphabet = "abcdefghijklmnñopqrstuvwxyz"
        return alphabet[self.randomInt(0,len(alphabet))]

    def randomConsonant(self):
        alphabet = "bdfghjklmnñpqrstvxyz"
        return alphabet[self.randomInt(0,len(alphabet))]
    
    def randomVocal(self):
        alphabet = "aeiou"
        return alphabet[self.randomInt(0,len(alphabet))]

    def randomWord(self):
        min=0
        max=self.randomInt(1,9)
        word =""
        for i in range (min,max):
            word += self.randomConsonant() +self.randomVocal()
            
        return word

    def randomSentence(self):
        min=0
        max=self.randomInt(1,10)
        sentence = self.randomWord()
        form=" {}"
        for i in range(min,max):
            sentence+= form.format(self.randomWord())
        sentence += "."
        return sentence

    def randomParagraph(self):
        min=0
        max=self.randomInt(1,15)
        paragraph = self.randomSentence()
        form=" {}"
        for i in range(min,max):
            paragraph+= form.format(self.randomSentence())
        return paragraph

    def randomText(self):
        min=0
        max=self.randomInt(1,15)
        text = self.randomParagraph()
        form="""
        {}"""
        for i in range(min,max):
            text+= form.format(self.randomParagraph())
        return text