#-*- coding : utf-8 -*-

class FileManager:
    def __init__(self):
        pass

        # filename debe ser = "nombredelarchivo.extenciondelmismo" 
        # ejemplo: archivodeCSV.csv

          
        # escribe o crea un archivo 
    def writeFile(self,fileName,content):
        f=open(fileName,"w")
        f.write(content)
        f.close()


    def readFile(self, fileName):
        f=open(fileName,"r")
        content= f.read() #este metodo no es optimo para todos los casos
                          #so se abre un archivo demasiado grande por ejemplo
        f.close()
        return content
