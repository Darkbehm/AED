#-*- coding : utf-8 -*-
from RandomManager import *

rm=RandomManager()
for i in range(1,25):

    print (rm.randomWord())
