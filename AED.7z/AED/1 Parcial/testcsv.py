#-*- coding :utf-8 -*-
from FileManager import FileManager
from MatrixManager import MatrixManager

fm=FileManager()
mm=MatrixManager()


content=fm.readFile("csvTest.csv")


matrix = mm.toMatrix(content)


htmlTable= mm.toHtml(matrix)

fm.writeFile("table.html",htmlTable)