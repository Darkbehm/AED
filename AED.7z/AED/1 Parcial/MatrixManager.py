#-*- coding : utf-8 -*-

class MatrixManager:
    def __init__ (self):
        pass
    
    def toString(self,matrix):
        stringMatrix=[]
        for vector in matrix:
            stringVector=[]
            for element in vector:
                stringVector.append(str(element))
            stringMatrix.append(stringVector)
        
        return stringMatrix


    def toMatrix(self,content):
        matrix= content.split("\n")
        
        for index in range(len(matrix)):
            matrix[index]= matrix[index].split(",")

        return matrix

    def toHtml(self,matrix):
        matrix = self.toString(matrix)
        html=[]

        for vector in matrix:
            html.append("<tr><td>%s</td></tr>"%("</td><td>".join(vector)))
        return ("<table border = border '1'>%s</table>"%("".join(html)))