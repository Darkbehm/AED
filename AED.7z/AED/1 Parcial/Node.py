class Node:
    def __init__(self,value):
        self.value = value
        self.next = None
        self.previous = None
