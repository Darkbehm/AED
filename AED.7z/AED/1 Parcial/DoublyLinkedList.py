#-*- coding : utf-8 -*-
from Node import Node

class DoubleLynkedList:
    def __init__(self):
        self.first=None
        self.last= None
        self.length = 0

    def push (self,value,position):
        if not isinstance(position,int) or position<0:
            return False
        # si el primer nodo esta vacio (la lista esta vacia), inserta el valor en el primer nodo
        node = Node(value)
        if not self.first:
            self.first = node
            self.updateLast()
            self.length+=1
            return True

        count = 0
        current = self.first

        #si la posicion es el primero        
        if position == 0 :
            queue = self.first
            self.first = node 
            self.first.next = queue
            self.first.next.previous = self.first
            self.updateLast()
            self.length +=1
            return True

        #caso general para cualquier posicion
        while current.next:
            if count + 1 == position:
                queue = current.next
                current.next = node
                current.next.next= queue
                current.next.previous= current
                self.updateLast()
                self.length+=1
                return True
            current=current.next
            count+=1
            
        
        current.next = node
        current.next.previous = current
        self.updateLast()
        self.length += 1
        return True

    def printFromFirst(self):
        if self.first==None:
            return None

        current =self.first 
        result = "None <=> %s <=> " %current.value
        while current.next :
            result += "%s <=> " %current.next.value
            current=current.next
        
        result+="None"

        return result
    
    def printFromLast(self):
        if self.last==None:
            return None

        current =self.last 
        result = "None <=> %s <=> " %current.value
        while current.previous :
            result += "%s <=> " %current.previous.value
            current=current.previous
        
        result+="None"

        return result
    
    #actualiza el last
    def updateLast(self):
        current = self.first

        while current.next:
            current= current.next
        
        self.last=current

    # elimina de la lista y retorna un elemento segun la posicion que enviemos, por defecto si
    # si la posicion enviada no existe en la lista entonces elimina el ultimo 
    def pop(self,position):
        if not isinstance(position,int) or position < 0:
            return False
        
        if position == 0:
            queue= self.first.next
            element = self.first.value
            self.first= queue
            self.first.previous = None
            self.length -=1
            return element

        if position > self.length - 1:
            element=self.last.value
            self.last.previous.next= None
            self.updateLast()
            self.length-=1
            return element
        
        count = 0
        current = self.first
        while current.next:
            if count+1 == position:
                element = current.value
                nextQueue = current.next
                previous = current.previous
                current = nextQueue
                current.previous= previous
                previous.next = current
                self.length-=1
                self.updateLast()
                return element
            current= current.next
            count+=1
            



ll=DoubleLynkedList()

ll.push(1,0)
print(ll.length)
print(ll.printFromFirst())
ll.push(2,9)
print(ll.length)
print(ll.printFromFirst())
ll.push(3,9)
print(ll.length)
print(ll.printFromFirst())
ll.push(4,9)
print(ll.length)
print(ll.printFromFirst())

print(ll.first.value)
print(ll.last.value)
print(ll.pop(2))
print(ll.pop(2))
print(ll.printFromFirst())
print(ll.printFromLast())

print(ll.length)

