#-*- coding:utf-8 -*-

from Node import Node

class Queue:
    def __init__(self):
        self.first=None 

    def push(self,value):
        if not self.first:
            self.first = Node(value)
            return True
        
        current = self.first
        while current.next:
            current=current.next

        current.next = Node(value)
        return True
        

    def print(self):
        if not self.first:
            return None
        
        current = self.first
        form ="{} => "
        result = " "
        
        while current:
            result += form.format(current.value)
            current=current.next

        result += "None"

        return result

    def pop(self):
        if not self.first:
            return False   

        current = self.first
        after = self.first.next
        current.next = None

        self.first = after
        
        return current.value
        

    def length(self):
        count=0
        current= self.first

        while current:
            count +=1
            current=current.next

        return count







