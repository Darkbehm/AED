#-*- coding: utf-8 -*-

from Node import Node

class Stack:
    def __init__(self):
        self.first=None

    def push(self,value):
        if not self.first:
            self.first=Node(value)
            return True
        
        current = self.first

        while current.next:
            current=current.next
        
        current.next=Node(value)
        return True

    def print(self):
        if not self.first:
            return None
        
        current = self.first
        form ="{} => "
        result = " "
        
        while current:
            result += form.format(current.value)
            current=current.next

        result += "None"

        return result
    def length(self):
        count=0
        current= self.first

        while current:
            count +=1
            current=current.next

        return count

    def pop(self):
        if self.length()==0:
            return None

        current= self.first
        if self.length()==1:
            self.first=None
            return current.value

        while current.next:
            beforeCurrent=current
            current= current.next
        
        beforeCurrent.next=None
        return current.value

        



        
        
        
           


