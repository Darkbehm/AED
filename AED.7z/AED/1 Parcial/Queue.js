function Queue(){
    this.first=null;


    this.push=QueuePush;
    this.print=QueuePrint;
    this.pop=QueuePop;
}

    function QueuePush(value){
        if(!this.first){
            this.first=new Node(value);
        }else{
            current=this.first;
            while(current.next){
                current=current.next;
            }
            current.next=new Node(value);
        }
    }

    function QueuePrint(){
        result="";
        current=this.first;
        
        while(current){
            result +=`${current.value}=>`;
            current=current.next;
        }
        result+= `null`;
        return result;    
    }

    function QueuePop(){
        if(this.first){
            this.first=this.first.next;
        }
    }

function Node(value){
    this.value=value;
    this.next= null;
}