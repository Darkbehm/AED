class HeapNode:
    def __init__(self,value):
        self.value=None
        self.left=None
        self.right=None
        self.position=None

class Heap:
    def __init__(self):
        self.root=None
        self.heigth=-1

    

    def addInner(self,value,current):
        if not self.root:
            self.root=HeapNode(value)

        current


