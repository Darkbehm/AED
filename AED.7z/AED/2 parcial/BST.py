# -*- coding : utf-8 -*-
from Node import BSTNode
from LinkedList import LinkedList

class BST :
    def __init__ (self):
        self.root = None

    #add:
    # metodo para añadir elementos al arbol
    #    este utiliza add inner para empezar  
    #    desde la raiz del arbol
    #retorna:    True si lo agrego False si no 
    #               lo agrego (si ya existia el valor dentro del arbol)

    def add(self,value):
        return self.addInner(value,self.root) 

    def addInner(self,value,current):
        if not self.root :
            node = BSTNode(value)
            self.root= node
            return True
        
        if not isinstance(current,BSTNode):
            return False

        if value < current.value :
            if not current.leftChild:
                current.leftChild = BSTNode(value)
                return True
            return self.addInner(value,current.leftChild)
        elif value > current.value:  
            if not current.rightChild:
                current.rightChild = BSTNode(value)
                return True
            return self.addInner(value,current.rightChild)
        else :
            return False 

    # search:
    #metodo para buscar o comprobar si un elemento existe 
    #dentro del arbol
    #    este utiliza search inner para empezar a buscar 
    #    desde la raiz del arbol
    #
    #retorna:    True si lo encontro
    #            False si no lo encontro

    def search(self,value):
        return self.searchInner(value,self.root)

    def searchInner(self,value,current):
        if not self.root:
            return False
        
        if not isinstance(current,BSTNode):
            return False
        
        if not current :
            return False

        if current.value == value:
                return True

        elif current.value> value:
            if not current.leftChild:
                return False
            return self.searchInner(value,current.leftChild)
        else:
            if not current.rightChild:
                return False
            return self.searchInner(value,current.rightChild)
           

    #metodo addLikedList agrega una linkedlist al arbol

    def addLinkedList(self,ll):
        if not isinstance(ll,LinkedList):
            return False
        current = ll.first
        while current:
            value=current.value
            self.add(value)
            current=current.next
        return True

    def createFromLinkedList(self,ll):
        if not isinstance(ll,LinkedList):
            return None
        
        tree=BST()
        tree.addLinkedList(ll)
        return tree
    


    #subtree devuelve un sub arbol buscando el valor que forma la raiz de este subarbol
    def subTree(self,value):
        return self.subTreeInner(value,self.root)

    def subTreeInner(self,value,current):
        if not self.root:
            return False
        
        if not isinstance(current,BSTNode):
            return False

        if current.value == value:
            tree = BST()
            tree.root= current
            return tree
        
        elif current.value>value:
            if not current.leftChild:
                return False
            return self.subTreeInner(value,current.leftChild)
        
        else:
            if not current.rightChild:
                return False
            return self.subTreeInner(value,current.rightChild)