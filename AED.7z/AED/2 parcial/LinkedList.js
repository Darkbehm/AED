function LinkedList(){
    this.first=null;
    this.size=0;
    this.push=LinkedListPush;
    this.pop=LinkedListPop;
    this.print= LinkedListPrint;
}
    function LinkedListPush(value,position=0){
        if(! position instanceof Number) return false;
        if (!this.first){
            this.first= new Node(value);
            this.size+=1;
            return true;
        }
        var current = this.first;
        var cont=0;
        if (position==0){
            this.first = new Node(value);
            this.first.next=current;
            this.size+=1;
            return true;
        }

        while (current.next){
            if(count+1 == position){
                var queue=current.next;
                current.next=new Node(value);
                current.next.next=queue;
                this.size+=1;
                return true;
            }
            count+=1;
            current= current.next;
        }

        current.next= new Node(value);
        this.size+=1;
        return true;
    }

    function LinkedListPop(position){
        if (position instanceof Number){
            if (position ==0){
                var element=this.first;
                var current=this.first.next;
                this.first=current;
                this.size-=1;
                return element;
            }
            var count = 0;
            var current=this.first;
            var before=current;

            while (current.next){
                if (count+1 == position){
                    var element=current.next.value;
                    current.next=current.next.next;
                    this.size-=1;
                    return element;
                }
                before=current;
                current=current.next;
                count+=1;
            }
            var element=current.value;
            before.next=null;
            this.size-=1;
            return element;
        }
        return false;
    }


    function LinkedListPrint(){
        if (this.first == null){
            return null;
        }
        var result="";
        var current=this.first;
        
        while(current){
            result +=`${current.value}=>`;
            current=current.next;
        }
        result+= `null`;
        return result; 
    }
   