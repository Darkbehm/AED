function MatrixManager(){
    this.toString= MatrixManagerToString;
    this.toMatrix= MatrixManagerToMatrix;
    this.toHTML= MatrixManagerToHTML;
    this.toMatrixFromBST=MatrixManagerToMatrixFromBST
    this.MatrixWidthForBST = MatrixManagerMatrixWidthForBST;
}

    function MatrixManagerToString(matrix){
        var stringMatrix=[];
        for(var i of matrix){
            var stringVector=[];
            for (var j of i){
                stringVector.push(String(j));
            }
            stringMatrix.push(String(stringVector));
        }
        return stringMatrix;
    }

    function MatrixManagerToMatrix(content){
        var matrix=content.split("\n");
        for (var i=0;i< matrix.length;i++){
            matrix [i]=matrix[i].split(",");
        }
        return matrix;
    }

    function MatrixManagerMatrixWidthForBST(n){
        if (n ==1)return 1;
        return this.MatrixWidthForBST(n-1)*2+1;
    }


    function MatrixManagerToHTML(matrix){
        var html=[]
        for (vector of matrix){
            html.push(`<tr><td>${vector.join("</td><td>")}</td></tr>"`)
        }
        return (`<table border ='1'>${html.join("")}</table>`)
    }

    function MatrixManagerToMatrixFromBST(bst) {
        var h = (bst.height())+1;
        var w = this.MatrixWidthForBST(h);
        var matrix = [];
        for (var i = 0; i < h; i++) {
            var row = [];
            for (var j = 0; j < w; j++) {
                row.push(0);
            }
            matrix.push(row);
        }
        return matrix;
    }