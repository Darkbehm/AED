# -*- coding : utf-8 -*-

class BSTNode:
    def __init__(self,value):
        self.value=value
        self.leftChild=None
        self.rightChild=None


class Node :
    def __init__(self):
        self.value=None
        self.next=None
