function BST() {
    this.root = null;
    this.add = BSTAdd;
    this.search = BSTSearch;
    this.addLinkedList = BSTAddLinkedList;
    this.createFrom = BSTCreateFrom;
    this.subTree = BSTSubTree;
    this.height=BSTHeight;
}

    function BSTAdd(value, current = this.root) {
        if (!this.root){
            this.root= new BSTNode(value);
            return true
        }
        if (!current instanceof BSTNode){
            return false;
        }

        if (value<current.value){
            if(!current.left){
                current.left= new BSTNode(value);
                return true;
            }
            return BSTAdd(value,current.left);
        }
        if (value> current.value){
            if (!current.right){
                current.right=new BSTNode(value);
                return true;
            }
            return BSTAdd(value,current.right);
        }
        return false;
    }

    function BSTSearch(value,current = this.root){
        if(!this.root){
            return false;
        }
        if (current instanceof BSTNode){
            if (this.first.value == value) return true;
            
            if (current.value==value)return true;
            if (current.value>value){
                if(!current.left)return false;
                return BSTSearch(value,current.left);
            }
            if (current.value<value){
                if (!current.right)return false;
                return BSTSearch(value,current.right);
            }
        }
        return false;
    }

    function BSTAddLinkedList(ll){
        if (ll instanceof LinkedList){
            var current= ll.first;

            while (current){
                var value = current.value
                this.add(value);
                current=current.next
            }
            return true
        }
        return false
    }

    function BSTCreateFrom(source){
        if (source instanceof LinkedList){
            var tree = new BST();
            tree.addLinkedList(source);
            return tree;
        }
        return null;
    }

    function BSTSubTree(value,current = this.root){
        if (!this.root){
            return null
        }
        if (current instanceof BSTNode){
            if (current.value== value){
                var tree = new BST();
                tree.root= current;
                return tree;
            }else if (current.value<value){
                if(!current.right)return false;
                return BSTSubTree(value,current.right);
            }else{
                if (!current.left)return false;
                return BSTSubTree(value,current.left);
            }
        }
        return false;
    }

    function BSTHeight(current=this.root){
        if (!this.root) return -1;
        if (current == null)return -1;
        if (!current.left && !current.right){
            current.height = 0
            return 0;
        } 
        var heightLeft = this.height(current.left);
        var heightRight = this.height(current.right);
        if ( heightLeft>heightRight){
            current.height= heightLeft+1;
            return heightLeft+1; 
        }
        else {
            current.height=heightRight+1;
            return heightRight+1; 
        }
    }