function Node(value){
    this.value =value;
    this.next=null;
}

