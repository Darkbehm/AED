#-*- coding: utf-8 -*-
from Node import Node

class LinkedList:
    def __init__(self):
        self.first=None
        self.length =0
        
    def push(self, value, position):
        if not isinstance(position,int) or position<0:
            return False

        if not self.first:
            self.first=Node(value)
            self.length+=1
            return True
        count = 0
        current = self.first

        while current.next :
            if count+1 == position :
                queue = current.next
                current.next= Node(value)
                current.next.next = queue
                self.length+=1
                return True
            current = current.next
            count+=1

        current.next = Node(value)
        self.length+=1

    def pop (self, position):
        if not isinstance(position,int) or position<0:
            return False
            # element es el valor del nodo que retornaremos 
            # current es la lista que tendremos ahora
            # cambiamor el primero por el valor que tendremos eliminando 
            # el valor anterior y retornando el mismo
        if position == 0:
            element = self.first.value
            current = self.first.next
            self.first = current
            self.length -=1
            return element

        count = 0
        current = self.first
        before = self.first
        while current.next:
            if count+1 == position:
                element=current.next.value
                current.next=current.next.next
                self.length-=1
                return element
            before = current
            current=current.next
            count +=1
        
        element=current.value
        before.next=None
        self.length-=1
        return element
       

    def print(self):
        if self.first==None:
            return None

        current =self.first 
        result = "%s => " %current.value
        while current.next :
            result += "%s => " %current.next.value
            current=current.next
        
        result+="None"

        return result

