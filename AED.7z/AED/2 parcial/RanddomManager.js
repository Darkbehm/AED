function RandomManager(){
    this.randomInt=RandomManagerRandomInt;

}
    function RandomManagerRandomInt(min = 0, max = 100){
        if (min>max)return null;
        var r= Math.random();
        return parseInt(r*(max-min)+min);
    }

    function RandomManagerRandomEvenInt(min = 0, max = 50){
        if (min>max)return null;
        return this.RandomInt(min,max/2)*2;
    }   