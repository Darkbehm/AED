function BSTNode(value){
    this.value=value;
    this.right=null;
    this.left=null;
    this.height=0;
}

