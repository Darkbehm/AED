# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Main.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets

from About import Ui_About
from PushMovie import Ui_PushMovie
from TreeGUI import Ui_Tree
from TableWindow import Ui_Table
from DictionaryManager import DictionaryManager
from LinkedList import *
from BST import *
from CategorieTree import *
from AsciiTable import*

class Ui_Main(object):
    def updateDict(self):
        
        self.dm.saveDict(self.linkedListData,self.BST)
        
        self.dm.readDict(self.BST,self.linkedListData,self.categorieTree)
        
        return True

    def openPushWindow(self):
            self.windowPush=QtWidgets.QMainWindow()
            self.uiPush= Ui_PushMovie()
            self.uiPush.setupUi(self.windowPush,self,0)
            self.windowPush.show()
    
    def openAboutWindow(self):
            self.windowAbout=QtWidgets.QMainWindow()
            self.uiAbout= Ui_About()
            self.uiAbout.setupUi(self.windowAbout)
            self.windowAbout.show()
    
    def openTableWindow(self):
        self.windowTable=QtWidgets.QMainWindow()
        self.uiTable= Ui_Table()
        self.uiTable.setupUi(self.windowTable,self)
        self.uiTable.textEdit.setText(self.table.table())
        self.windowTable.show()

    def openTreeWindow(self):
        self.windowTree=QtWidgets.QMainWindow()
        self.uiTree= Ui_Tree()
        self.uiTree.setupUi(self.windowTree,self.BST,self.categorieTree)
        self.windowTree.show()

    def setupUi(self, Main):
        self.dm =DictionaryManager()
        self.linkedListData= LinkedList()
        self.BST = BST()
        self.categorieTree= CategorieTree()
        
        try:
            self.dm.readDict(self.BST,self.linkedListData,self.categorieTree)
        except FileNotFoundError :
            pass

        self.table= AsciiTable(self.linkedListData)

        

        Main.setObjectName("Main")
        Main.setMaximumSize(573, 626)
        Main.setMinimumSize(573, 626)
        self.centralwidget = QtWidgets.QWidget(Main)
        self.centralwidget.setObjectName("centralwidget")
        self.frmMain = QtWidgets.QFrame(self.centralwidget)
        self.frmMain.setGeometry(QtCore.QRect(0, 0, 571, 601))
        self.frmMain.setStyleSheet("background-color: rgb(243, 243, 243);")
        self.frmMain.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frmMain.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frmMain.setObjectName("frmMain")

        self.btnAbout = QtWidgets.QPushButton(self.frmMain)
        self.btnAbout.setGeometry(QtCore.QRect(360, 20, 191, 51))
        self.btnAbout.setStyleSheet("background-color: rgb(141, 124, 194);\n"
        "color: rgb(255, 255, 255);\n"
        "border-radius: 20px")
        self.btnAbout.setObjectName("btnAbout")
        
        self.btnAbout.clicked.connect(self.openAboutWindow)
        
        self.btnPushMovie = QtWidgets.QPushButton(self.frmMain)
        self.btnPushMovie.setGeometry(QtCore.QRect(150, 300, 301, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnPushMovie.setFont(font)
        self.btnPushMovie.setStyleSheet("background-color: rgb(141, 124, 194);\n"
        "color: rgb(255, 255, 255);\n"
        "border-radius: 30px")
        self.btnPushMovie.setObjectName("btnPushMovie")
        
        self.btnPushMovie.clicked.connect(self.openPushWindow)
        
        self.btnPrintEdit = QtWidgets.QPushButton(self.frmMain)
        self.btnPrintEdit.setGeometry(QtCore.QRect(150, 380, 301, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnPrintEdit.setFont(font)
        self.btnPrintEdit.setStyleSheet("background-color:rgb(254, 217, 102);\n"
        "color:  rgb(141, 124, 194);\n"
        "border-radius: 30px")
        self.btnPrintEdit.setObjectName("btnPrintEdit")
        
        self.btnPrintEdit.clicked.connect(self.openTableWindow)
        
        self.btnPrintTrees = QtWidgets.QPushButton(self.frmMain)
        self.btnPrintTrees.setGeometry(QtCore.QRect(150, 460, 301, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnPrintTrees.setFont(font)
        self.btnPrintTrees.setStyleSheet("background-color: rgb(109, 158, 237);\n"
        "color: rgb(255, 255, 255);\n"
        "border-radius: 30px;")
        self.btnPrintTrees.setObjectName("btnPrintTrees")
        
        self.btnPrintTrees.clicked.connect(self.openTreeWindow)
        
        
        self.CountMovie = QtWidgets.QLabel(self.frmMain)
        self.CountMovie.setGeometry(QtCore.QRect(290, 130, 81, 61))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.CountMovie.setFont(font)
        self.CountMovie.setObjectName("CountMovie")
        self.label = QtWidgets.QLabel(self.frmMain)
        self.label.setGeometry(QtCore.QRect(258, 190, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.label.setFont(font)
        self.label.setObjectName("label")
        Main.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(Main)
        self.statusbar.setObjectName("statusbar")
        Main.setStatusBar(self.statusbar)

        self.retranslateUi(Main)

        self.CountMovie.setText(str(self.linkedListData.length()))
        QtCore.QMetaObject.connectSlotsByName(Main)

    def retranslateUi(self, Main):
        _translate = QtCore.QCoreApplication.translate
        Main.setWindowTitle(_translate("Main", "MainWindow"))
        self.btnAbout.setText(_translate("Main", "Acerca De"))
        self.btnPushMovie.setText(_translate("Main", "Agregar "))
        self.btnPrintEdit.setText(_translate("Main", "Ver y Editar Listado"))
        self.btnPrintTrees.setText(_translate("Main", "Visualizacion de Arboles"))
        self.CountMovie.setText(_translate("Main", "0"))
        self.label.setText(_translate("Main", "Películas"))


if __name__ == "__main__":
    import sys
    
    app = QtWidgets.QApplication(sys.argv)
    Main = QtWidgets.QMainWindow()
    ui = Ui_Main()
    ui.setupUi(Main)
    Main.show()
    sys.exit(app.exec_())

