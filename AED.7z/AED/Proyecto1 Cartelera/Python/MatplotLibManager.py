
class MatplotlibManager:
    
    #recibe lst:lista con los nodos bst que se imprimiran,y el canvas(plot o axe) donde se imprimira
    def createTreeFromLst(self,lst,plt):
        maxh=3
        ax=plt

        for i in range(len(lst)):
            node=lst[i]
            x = node['x']*20
            y = node['y']*10

            value = "%s"%(node['name'])

            if node['y'] ==2 or node['y']==3 :
                for i in range(len(node['children'])):
                    xf=(node['children'][i][0])*20
                    yf=(node['children'][i][1])*10
                    ax.arrow(x, y, xf-x, yf-y,length_includes_head=True, fc='k', ec='k')
    
            plt.text(x, y, value, size=10,
                    ha="center", va="center",
                    bbox=dict(edgecolor='k',
                    facecolor='pink',
                    fill=True,
                    linewidth=2,
                    boxstyle='round')
                    )

        mi = (pow(2,maxh-1))-1
        mf = mi*2
        w = mf+1
        plt.set_xlim(-5,w*10+5)
        plt.set_ylim(-2,maxh*10+3)

        plt.set_axis_off()


    def createBSTFromLst(self,lst,plt):
        maxh=0
        ax = plt
        for i in range(len(lst)):
            #esteblece las coorddenadas de donde se mostrara el cuadro(node)
            node=lst[i]
            x= node['x']*10
            y= node['y']*3

            if node['right']:
                #si tiene nodo hijo derecho entonces calcula las coordenadas para imprimir la flecha apuntando a este
                
                xf=(node['right'][0])*10
                yf=(node['right'][1])*3
                ax.arrow(x, y, xf-x, yf-y,length_includes_head=True, fc='k', ec='k')
              
            if node['left']:

                #si tiene nodo hijo izquierdo calcula coordenadas para imprimir la flecha apundtando a este
                xf=(node['left'][0])*10
                yf=(node['left'][1])*3
                ax.arrow(x, y, xf-x, yf-y ,length_includes_head=True, fc='k', ec='k')
                        
            #-----------------------------------------
            
            #altura maxima usada para calcular los limites de la grafica
            if maxh<node['y']:
                maxh=node['y']
            
            #
            value = "%s\n%s" %(node['duration'],node['name'])

       
            plt.text(x, y, value, size=10,
                    ha="center", va="center",
                    bbox=dict(edgecolor='k',
                    facecolor='pink',
                    fill=True,
                    linewidth=2,
                    boxstyle='round')
                    )

        mi = (pow(2,maxh-1))-1
        mf = mi*2
        w = mf+1
        plt.set_xlim(-5,w*10+5)
        plt.set_ylim(-2,maxh*3+3)
        
        plt.set_axis_off()

        