# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Confirmacion.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!

import sys
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Confirmation(object):

    def clickOk(self,Form):
        movie=self.main.linkedListData.getById(self.position)
        
        self.main.BST.deleteMovie(movie)
        
        self.main.categorieTree.delete(movie)

        self.main.linkedListData.delete(self.position)

        self.main.CountMovie.setText("%s"%(self.main.linkedListData.length()))

        self.main.updateDict()
        self.main.openTableWindow()
        self.form.close()
        
    
    def clickNo(self):
        self.form.close()

    def setupUi(self, Form,main,position):
        self.main=main
        self.position=position
        Form.setObjectName("Form")
        Form.resize(304, 150)
        self.form=Form
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(30, 30, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.btnAcept = QtWidgets.QPushButton(Form)
        self.btnAcept.setGeometry(QtCore.QRect(60, 70, 81, 61))
        self.btnAcept.setStyleSheet("background-color: rgb(109, 158, 235);\n"
"color: rgb(255, 255, 255);\n"
"border-radius: 30px")
        self.btnAcept.setObjectName("btnAcept")

        self.btnAcept.clicked.connect(self.clickOk)

        self.btnCancel = QtWidgets.QPushButton(Form)
        self.btnCancel.setGeometry(QtCore.QRect(170, 70, 81, 61))
        self.btnCancel.setStyleSheet("background-color: rgb(224, 102, 101);\n"
"color: rgb(255,255,255);\n"
"border-radius: 30px;")
        self.btnCancel.setObjectName("btnCancel")

        self.btnCancel.clicked.connect(self.clickNo)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "ADVERTENCIA"))
        self.label.setText(_translate("Form", "Esta seguro de eliminar esta pelicula?"))
        self.btnAcept.setText(_translate("Form", "Aceptar"))
        self.btnCancel.setText(_translate("Form", "Cancelar"))
