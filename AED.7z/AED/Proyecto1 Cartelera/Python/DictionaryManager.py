# -*- coding:utf-8 -*-
from LinkedList import *
from FileManager import *
from Movie import *
from CategorieTree import *
fm= FileManager()

#---------------------------------------------------------------------------------------------------------
class DictionaryManager:
    def __init__(self):
        pass

    def createTree(self, dct, tree):
    #recibe el diccionario generado por el bst y dependiendo del tree que reciba entonces genera ese arbol con su metodo add
        for key,value in dct.items():
            if key == 'root':
                if value == None:
                    return tree
                self.createTree(value,tree)

            if key=='movie':
                name=value['name']
                duration=value['duration']
                director=value['director']
                description=value['description']
                categorie=value['categorie']
                movie=Movie(name,duration,director,description,categorie)

                tree.add(movie)
            
            
            if key== 'left' or key == 'right':
                self.createTree(value,tree)

        return tree

    #el siguiente metodo convierte un diccionario a una cadena, el cual sera usado como transicion para luego crear nuestro arbol 
    def dictionaryToLl(self, d,linkedList):
        ll = linkedList
        if isinstance(d, dict):
            ll=self.dictonaryToLlInner(d, ll)
        return ll

    def dictonaryToLlInner(self, dct, ll):
        for key,value in dct.items():
            if key == 'first':
                if not value:
                    return ll
                self.dictonaryToLlInner(value,ll)

            if key=='movie':
                   
                name=value['name']
                duration=value['duration']
                director=value['director']
                description=value['description']
                categorie=value['categorie']
                movie=Movie(name,duration,director,description,categorie)

                ll.push(movie)
            
            if key == 'next':
                self.dictonaryToLlInner(value,ll)

        return ll

    #el siguiente metodo convierte una lista enlazada a un diccionario.
    def generateDictFromLinkedList(self, ll):
        if isinstance(ll,LinkedList):

            current= ll.first  
            if current==None:
                string='{"first": None }'
                return string

            string='{"first":{"movie":{"name":"%s","duration":"%s","director":"%s","description":"%s","categorie":"%s"},"next":{'%(current.value.name,current.value.duration,current.value.director,current.value.description,current.value.categorie)

            count=1
            while current.next:
                string+='"movie":{"name":"%s","duration":"%s","director":"%s","description":"%s","categorie":"%s"},"next":{'%(current.value.name,current.value.duration,current.value.director,current.value.description,current.value.categorie)
                count +=1
                current=current.next

            string+="}"*count
            string+="}"+"}"

        return string

    def saveDict(self, ll, bst):
        bstString = bst.generateStringDict()
        llString = self.generateDictFromLinkedList(ll)

        data = '{"BST": %s, "LinkedList": %s}'%(bstString, llString)

        fm.writeFile("Data.json", data)

        return True

    def readDict(self, bst, ll, tree):
        data = fm.readFile("Data.json")

        if data:
            dictionary = eval(data)
        else:
            return False
            
        ll = self.dictionaryToLl(dictionary["LinkedList"], ll)
        bst = self.createTree(dictionary["BST"],bst)
        tree = self.createTree(dictionary["BST"],tree)
        
        
        return True
