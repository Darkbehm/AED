# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'advice.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Advice(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(450, 200)
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(30, 20, 440, 160))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label.setFont(font)
        self.label.setObjectName("label")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("ADVERTENCIA", "ADVERTENCIA"))
        self.label.setText(_translate("Form", "Nombre debe llevar minimo 1 caracter\nFormato de la duracion incorrecto\nDirector debe llevar minimo 1 caracter\nDescripcion debe llevar minimo 10 caracteres"))
