# -*- coding: utf-8 -*-
from LinkedList import *
from Movie import *
class AsciiTable():

    def __init__(self,linkedList):
       self.list = linkedList

   
    def table(self):
             
        table = []
        table.append("-"*220)
        table.append(" "*70 + "Lista de peliculas") 
        table.append("-"*220)
        table.append("Id."+"\t"+ "|"+"\tNombre"+"\t\t\t"+"|" +"\tDuracion"+"\t\t" +"|" +"\tDescripcion")
        table.append("-"*220)

        
        if (self.list.length() > 0):
            table.append(self.list.print())
                
        
           
        table.append("-"*220)
        
        retVal = "\n".join(table)
        return retVal

