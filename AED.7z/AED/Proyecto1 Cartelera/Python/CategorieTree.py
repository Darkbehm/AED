# -*- coding:utf-8 -*-

from Movie import *
from Nodes import NodeTP


import math
#----------------------------------------------------------------------------------------------------
class CategorieTree:
    def __init__(self):
        self.root = NodeTP("Categorias")
        self.root.children.push(NodeTP("Hechos Reales"))
        self.root.children.push(NodeTP("Bélicas"))
        self.root.children.push(NodeTP("Comedias Musicales"))
        self.root.children.push(NodeTP("Acción"))
        self.root.children.push(NodeTP("Artes Marciales"))
        self.root.children.push(NodeTP("Aventuras"))
        self.root.children.push(NodeTP("Ciencia Ficción"))
        self.root.children.push(NodeTP("Comedia"))
        self.root.children.push(NodeTP("Dibujos Animados"))
        self.root.children.push(NodeTP("Documental"))
        self.root.children.push(NodeTP("Espada y Hechicería"))
        self.root.children.push(NodeTP("Espionaje"))
        self.root.children.push(NodeTP("Horror"))
        self.root.children.push(NodeTP("Misterio"))
        self.root.children.push(NodeTP("Muertos Vivientes"))
        self.root.children.push(NodeTP("Propaganda"))
        self.root.children.push(NodeTP("Suspenso"))
        self.root.children.push(NodeTP("Terror"))
        self.root.children.push(NodeTP("Deportiva"))
        self.root.children.push(NodeTP("Dramática"))
        self.root.children.push(NodeTP("Fantástica"))
        self.root.children.push(NodeTP("Infantil"))
        self.root.children.push(NodeTP("Musical"))
        self.root.children.push(NodeTP("Policíaca"))
        self.root.children.push(NodeTP("Psicológica"))
        self.root.children.push(NodeTP("Romántica"))
        self.root.children.push(NodeTP("Animales"))
        self.root.children.push(NodeTP("Aviación"))
        self.root.children.push(NodeTP("Delincuencia"))
        self.root.children.push(NodeTP("Discapacitados"))
        self.root.children.push(NodeTP("Religión"))
        self.root.children.push(NodeTP("Política"))
        self.root.children.push(NodeTP("--Ninguno--"))

        self.size=31
        #los siguientes metodos serviran tomando como parametro un value=id, y un current que en su momento contendra al nodo raiz del arbol para saber cual elemento se borrara

    def add(self, movie):
        categorie=movie.categorie
        if not isinstance(movie,Movie):
            return False

        if not categorie:
            return False

        if isinstance(categorie, str):
            current = self.root.children.first
            while current:
                if categorie == current.value.value:
                    current.value.children.push(movie)
                    self.size+=1
                current = current.next

    def print(self, current=None, tab=""):
        if not current:
            return False
        if isinstance(current, NodeTP):
            current.children.print()
        else:
            return False

    def search(self, value):
        if not current:
            return False
        if isinstance(current, NodeTP):
            current.children.Search(value)
        else: 
            return False

       

    def delete(self,movie):
        categorie = movie.categorie
        self.deleteInner(movie,categorie)

    def deleteInner(self,movie,categorie):
        currentCategorie=self.root.children.first
        while currentCategorie:
            if currentCategorie.value.value == categorie:
                position=currentCategorie.value.children.find(movie)
                currentCategorie.value.children.delete(position)
                self.size += -1
                return True
            currentCategorie=currentCategorie.next

    def edit(self,movieOriginal,movieEdited):
        categorie = movieOriginal.categorie
        newCategorie= movieEdited.categorie
        currentCategorie=self.root.children.first
        while currentCategorie:
            if currentCategorie.value.value == categorie:
                position=currentCategorie.value.children.find(movieOriginal)
                if currentCategorie.value.value == newCategorie:
                    currentCategorie.value.children.edit(movieEdited,position)
                else:
                    currentCategorie.value.children.delete(position)
                    self.add(movieEdited)
                return False
            currentCategorie=currentCategorie.next

    def createListToPrint(self):
        treeList= []

        position = 0
        h = 3
        w = self.size
        middle= math.ceil(w/2)

        children=31
        currentCategorie=self.root.children.first
        #primer nodo
        treeList.append({'x':middle,'y':3,'name':"Categorias",'children':[]})
        x=0
        countCategorie=0
        while currentCategorie:
            countCategorie+=1
            node={'y':2,'name':currentCategorie.value.value}
            countMovie=0
            currentMovie=currentCategorie.value.children.first
            xTemporal=x
            movieList=[]
            while currentMovie:
                countMovie+=1
                x+=1
                movieNode={'x':x,'y':1,'name':currentMovie.value.name}
                treeList.append(movieNode)
                currentMovie=currentMovie.next
                movieList.append([movieNode['x'],movieNode['y']])
            
            node['children']=movieList
            node['x']=xTemporal+int(countMovie/2)+1
            if countMovie==0:
                x+=1
            treeList.append(node)
            treeList[0]['children'].append([node['x'],node['y']])

            currentCategorie=currentCategorie.next

        return treeList
            




       