#-*- coding: utf-8 -*-

class TimeManager:
    def __init__(self):
        pass

    def convertStringToInt(self,string):
        if not self.stringValidator(string):return False
        
        array = string.split(":")

        if not self.stringValidator(array):return False

        time = int(array[2]) + (int(array[1]) + int(array[0])*60)*60
        if time > 46800:return False
        return  time
        
    def stringValidator(self,string):

        #valida si es string y  si tiene ':' 2 veces como el formato (00:00:00) 
        #retorna true si se cumple y false si no 
        if (isinstance(string,str)) and (string.count(":")==2) and (len(string)==8):
            return True

        #valida si es una lista con 3 elementos string numericos y que
        #el primero (horas) este en rango de 0-12 y que 
        #el segundo (minutos) y tercero (segundos) esten en rango de 0-59
        #retorna true si se cumple y false si no 
        elif isinstance(string,list) and len(string)== 3:
            for i in range(len(string)):

                if not isinstance(string[i],str) and len(string[i])!=2:
                    return False
                if not string[i].isdigit() : 
                    return False
                if int(string[i])<0 : 
                    return False

            if (int(string[0])<13 or int(string[1])<60 or int(string[2])<60 ):
                return True

        else:
            return False 

    def convertIntToString(self,integer):
        hour = int(integer/3600)

        minute = int((integer-(hour*3600))/60)
        second = int(integer-((hour*3600)+(minute*60)))
        timeArray = [hour,minute,second]

        string="%s:%s:%s" %(timeArray[0],timeArray[1],timeArray[2])

        return string

