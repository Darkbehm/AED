# -*- coding: utf-8 -*-
class FileManager:

    def __inti__(self):
        pass
    
    #metodo que servira para leer un archivo creado
    def readFile(self, fileName):
        #mode = "r" o sea read
        f = open(fileName, "r")
        content = f.read()
        f.close()
        return content

    #este metodo crea archivos, pero para que funcione el contenido del archivo a crear debe ser tipo str
    def writeFile(self, fileName, content):
        #mode = "w" o sea write
        f = open(fileName, "w")
        f.write(content)
        f.close()
