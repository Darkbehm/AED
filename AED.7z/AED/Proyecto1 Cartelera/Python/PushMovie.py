# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'PushMovie.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from Movie import Movie
from TimeManager import TimeManager 

tm=TimeManager()

from Advice import Ui_Advice

class Ui_PushMovie(object):

    def openWarning(self):
        self.windowAdvice=QtWidgets.QMainWindow()
        self.uiAdvice= Ui_Advice()
        self.uiAdvice.setupUi(self.windowAdvice)
        self.windowAdvice.show()
 
    def add(self):
        name=self.txtNameMovie.toPlainText()
        
        if (len(name)<1):
                self.openWarning()
                return False
        duration= self.txtDurationMovie.toPlainText() 
       
        if tm.convertStringToInt(duration)==False:
            self.openWarning()
            return False

        director= self.txtDirectorMovie.toPlainText()
        if (len(director)<3):
                self.openWarning()
                return False
        description=self.txtDescriptionMovie.toPlainText()
        if (len(description)<10):
                self.openWarning()
                return False
        categorie= self.cbItemsMovie.itemText(self.cbItemsMovie.currentIndex())

        movie= Movie(name,duration,director,description,categorie)
        if self.position>0:
            originalMovie=self.linkedList.getById(self.position)
            self.linkedList.edit(movie,self.position)
            self.BST.deleteMovie(originalMovie)
            self.BST.add(movie)
            self.categorieTree.edit(originalMovie,movie)
            self.countMovie.setText("%s"%(self.linkedList.length()))
            self.main.updateDict()
            self.main.openTableWindow()
            self.PushMovie.close()
        else:
            self.linkedList.push(movie)
            self.BST.add(movie)
            self.categorieTree.add(movie)
            self.countMovie.setText("%s"%(self.linkedList.length()))
            self.main.updateDict()
        
        self.clearValues()

    def clearValues(self):
        self.txtDescriptionMovie.setText("")
        self.txtNameMovie.setText("")
        self.txtDirectorMovie.setText("")
        self.txtDurationMovie.setText("")


    def setupUi(self, PushMovie,main,position):
        self.linkedList=main.linkedListData
        self.position=position
        self.BST=main.BST
        self.categorieTree=main.categorieTree
        self.countMovie=main.CountMovie
        self.main=main
        PushMovie.setObjectName("PushMovie")
        PushMovie.setMaximumSize(1052, 636)
        PushMovie.setMinimumSize(1052, 636)
        self.PushMovie=PushMovie
        font = QtGui.QFont()
        font.setPointSize(12)
        self.frmPush = QtWidgets.QFrame(PushMovie)
        self.frmPush.setGeometry(QtCore.QRect(0, 0, 1052, 651))
        self.frmPush.setStyleSheet("background-color: rgb(243, 243, 243);")
        self.frmPush.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frmPush.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frmPush.setObjectName("frmPush")

        self.txtNameMovie = QtWidgets.QTextEdit(self.frmPush)
        self.txtNameMovie.setGeometry(QtCore.QRect(30, 50, 992, 41))
        self.txtNameMovie.setStyleSheet("background-color: rgb(255,255,255);\n"
        "font: 14pt \"MS Shell Dlg 2\";\n"
        "color:rgb(0,0,0)")
        self.txtNameMovie.setObjectName("txtNameMovie")
        
        self.txtNameMovie.setFont(font)

        self.txtDurationMovie = QtWidgets.QTextEdit(self.frmPush)
        self.txtDurationMovie.setGeometry(QtCore.QRect(30, 130, 992, 41))
        self.txtDurationMovie.setStyleSheet("background-color: rgb(255,255,255);\n"
        "color:rgb(0,0,0)")
        self.txtDurationMovie.setObjectName("txtDurationMovie")
        self.txtDurationMovie.setFont(font)

        self.txtDescriptionMovie = QtWidgets.QTextEdit(self.frmPush)
        self.txtDescriptionMovie.setGeometry(QtCore.QRect(30, 210, 992, 101))
        self.txtDescriptionMovie.setStyleSheet("background-color: rgb(255,255,255);\n"
        "color:rgb(0,0,0)")
        self.txtDescriptionMovie.setObjectName("txtDescriptionMovie")
        self.txtDescriptionMovie.setFont(font)

        self.txtDirectorMovie = QtWidgets.QTextEdit(self.frmPush)
        self.txtDirectorMovie.setGeometry(QtCore.QRect(30, 360, 992, 41))
        self.txtDirectorMovie.setFont(font)
        self.txtDirectorMovie.setStyleSheet("background-color: rgb(255,255,255);\n"
        "color:rgb(0,0,0)")
        self.txtDirectorMovie.setObjectName("txtDirectorMovie")
        self.cbItemsMovie = QtWidgets.QComboBox(self.frmPush)
        self.cbItemsMovie.setGeometry(QtCore.QRect(30, 460, 992, 41))
        self.cbItemsMovie.setFont(font)
        self.cbItemsMovie.setObjectName("cbItemsMovie")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")
        self.cbItemsMovie.addItem("")


        self.btnDelete = QtWidgets.QPushButton(self.frmPush)
        self.btnDelete.setGeometry(QtCore.QRect(270, 560, 251, 71))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnDelete.setFont(font)
        self.btnDelete.setStyleSheet("background-color: rgb(224, 102, 101);\n"
        "color: rgb(255,255,255);\n"
        "border-radius: 30px;")
        self.btnDelete.setObjectName("btnDelete")

        self.btnDelete.clicked.connect(self.clearValues)

        self.btnAdd = QtWidgets.QPushButton(self.frmPush)
        self.btnAdd.setGeometry(QtCore.QRect(560, 560, 251, 71))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnAdd.setFont(font)
        self.btnAdd.setStyleSheet("background-color: rgb(109, 158, 235);\n"
        "color: rgb(255, 255, 255);\n"
        "border-radius: 30px")
        self.btnAdd.setObjectName("btnAdd")
        self.btnAdd.clicked.connect(self.add)


        self.lbNameMovie = QtWidgets.QLabel(self.frmPush)
        self.lbNameMovie.setGeometry(QtCore.QRect(30, 10, 181, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbNameMovie.setFont(font)
        self.lbNameMovie.setStyleSheet("background-color: rgba(255, 255, 255, 55);")
        self.lbNameMovie.setObjectName("lbNameMovie")
        self.lbDurationMovie = QtWidgets.QLabel(self.frmPush)
        self.lbDurationMovie.setGeometry(QtCore.QRect(30, 90, 281, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbDurationMovie.setFont(font)
        self.lbDurationMovie.setStyleSheet("font: 12pt \"MS Shell Dlg 2\";\n"
        "background-color: rgba(255, 255, 255, 55);")
        self.lbDurationMovie.setObjectName("lbDurationMovie")
        self.lbDescriptionMovie = QtWidgets.QLabel(self.frmPush)
        self.lbDescriptionMovie.setGeometry(QtCore.QRect(30, 170, 281, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbDescriptionMovie.setFont(font)
        self.lbDescriptionMovie.setStyleSheet("background-color: rgba(255, 255, 255, 55);")
        self.lbDescriptionMovie.setObjectName("lbDescriptionMovie")
        self.lbNameDirectorMovie = QtWidgets.QLabel(self.frmPush)
        self.lbNameDirectorMovie.setGeometry(QtCore.QRect(30, 310, 301, 51))
        self.lbNameDirectorMovie.setStyleSheet("font: 12pt \"MS Shell Dlg 2\";\n"
        "background-color: rgba(255, 255, 255, 55);")
        self.lbNameDirectorMovie.setObjectName("lbNameDirectorMovie")
        self.lbCategories = QtWidgets.QLabel(self.frmPush)
        self.lbCategories.setGeometry(QtCore.QRect(30, 410, 101, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbCategories.setFont(font)
        self.lbCategories.setStyleSheet("background-color: rgba(255, 255, 255, 55);")
        self.lbCategories.setObjectName("lbCategories")
        self.txtDurationMovie.raise_()
        self.txtNameMovie.raise_()
        self.txtDescriptionMovie.raise_()
        self.txtDirectorMovie.raise_()
        self.cbItemsMovie.raise_()
        self.btnDelete.raise_()
        self.btnAdd.raise_()
        self.lbNameMovie.raise_()
        self.lbDurationMovie.raise_()
        self.lbDescriptionMovie.raise_()
        self.lbNameDirectorMovie.raise_()
        self.lbCategories.raise_()

        self.retranslateUi(PushMovie)

        if position>0:
            movie=self.linkedList.getById(position)
            self.txtDescriptionMovie.setText(movie.description)
            self.txtNameMovie.setText(movie.name)
            self.txtDirectorMovie.setText(movie.director)
            self.txtDurationMovie.setText(movie.duration)
        else:
            self.txtDurationMovie.setText("")
            self.txtDescriptionMovie.setText("")
            self.txtNameMovie.setText("")
            self.txtDirectorMovie.setText("")
        QtCore.QMetaObject.connectSlotsByName(PushMovie)

    def retranslateUi(self, PushMovie):
        _translate = QtCore.QCoreApplication.translate
        if self.position==0:
            PushMovie.setWindowTitle(_translate("PushMovie", "Agregar Pelicula"))
        else:
            PushMovie.setWindowTitle(_translate("PushMovie", "Editar Pelicula"))

        self.txtNameMovie.setHtml(_translate("PushMovie", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:14pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:13pt;\"><br /></p></body></html>"))
        self.txtDurationMovie.setHtml(_translate("PushMovie", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;\"><br /></p></body></html>"))
        self.txtDescriptionMovie.setHtml(_translate("PushMovie", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\"><br /></span></p></body></html>"))
        self.txtDirectorMovie.setHtml(_translate("PushMovie", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:13pt;\"><br /></p></body></html>"))
        self.cbItemsMovie.setItemText(0, _translate("PushMovie", "--Ninguno--"))
        self.cbItemsMovie.setItemText(1, _translate("PushMovie", "Hechos Reales"))
        self.cbItemsMovie.setItemText(2, _translate("PushMovie", "Bélicas"))
        self.cbItemsMovie.setItemText(3, _translate("PushMovie", "Comedias Musicales"))
        self.cbItemsMovie.setItemText(4, _translate("PushMovie", "Acción"))
        self.cbItemsMovie.setItemText(5, _translate("PushMovie", "Artes Marciales"))
        self.cbItemsMovie.setItemText(6, _translate("PushMovie", "Aventuras"))
        self.cbItemsMovie.setItemText(7, _translate("PushMovie", "Ciencia Ficción"))
        self.cbItemsMovie.setItemText(8, _translate("PushMovie", "Comedia"))
        self.cbItemsMovie.setItemText(9, _translate("PushMovie", "Dibujos Animados"))
        self.cbItemsMovie.setItemText(10, _translate("PushMovie", "Documental"))
        self.cbItemsMovie.setItemText(11, _translate("PushMovie", "Espada y Hechicería"))
        self.cbItemsMovie.setItemText(12, _translate("PushMovie", "Espionaje"))
        self.cbItemsMovie.setItemText(13, _translate("PushMovie", "Horror"))
        self.cbItemsMovie.setItemText(14, _translate("PushMovie", "Misterio"))
        self.cbItemsMovie.setItemText(15, _translate("PushMovie", "Muertos Vivientes"))
        self.cbItemsMovie.setItemText(16, _translate("PushMovie", "Propaganda"))
        self.cbItemsMovie.setItemText(17, _translate("PushMovie", "Suspenso"))
        self.cbItemsMovie.setItemText(18, _translate("PushMovie", "Terror"))
        self.cbItemsMovie.setItemText(19, _translate("PushMovie", "Deportiva"))
        self.cbItemsMovie.setItemText(20, _translate("PushMovie", "Dramática"))
        self.cbItemsMovie.setItemText(21, _translate("PushMovie", "Fantástica"))
        self.cbItemsMovie.setItemText(22, _translate("PushMovie", "Infantil"))
        self.cbItemsMovie.setItemText(23, _translate("PushMovie", "Musical"))
        self.cbItemsMovie.setItemText(24, _translate("PushMovie", "Policíaca"))
        self.cbItemsMovie.setItemText(25, _translate("PushMovie", "Psicológica"))
        self.cbItemsMovie.setItemText(26, _translate("PushMovie", "Romántica"))
        self.cbItemsMovie.setItemText(27, _translate("PushMovie", "Animales"))
        self.cbItemsMovie.setItemText(28, _translate("PushMovie", "Aviación"))
        self.cbItemsMovie.setItemText(29, _translate("PushMovie", "Delincuencia"))
        self.cbItemsMovie.setItemText(30, _translate("PushMovie", "Discapacitados"))
        self.cbItemsMovie.setItemText(31, _translate("PushMovie", "Religión"))
        self.cbItemsMovie.setItemText(32, _translate("PushMovie", "Política"))
        self.btnDelete.setText(_translate("PushMovie", "Limpiar"))
        self.btnAdd.setText(_translate("PushMovie", "Agregar"))
        self.lbNameMovie.setText(_translate("PushMovie", "Ingrese el nombre:"))
        self.lbDurationMovie.setText(_translate("PushMovie", "Duración de la película: HH:MM:SS"))
        self.lbDescriptionMovie.setText(_translate("PushMovie", "Ingrese la descripción de la película:"))
        self.lbNameDirectorMovie.setText(_translate("PushMovie", "Nombre del director de la Película:"))
        self.lbCategories.setText(_translate("PushMovie", "Categoria:"))

