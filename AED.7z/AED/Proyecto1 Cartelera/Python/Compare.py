#-*-coding : utf-8 -*-

class Compare:
    def __init__(self):
        self.alphabet = ",;.:<>?/|\!@#$%^&*()-_=+`~0123456789abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZáéíóúÁÉÍÓÚäëïöüÄËÏÖÜ"

    def compareMin(self,str1,str2):
        return min(len(str1),len(str2)) 

    def compare(self,string1,string2):
        minimum=self.compareMin(string1,string2)

        for i in range(minimum):
            if self.alphabet.find(string1[i])>self.alphabet.find(string2[i]):
                return 1
            elif self.alphabet.find(string1[i])<self.alphabet.find(string2[i]):
                return -1

        if len(string1)>len(string2):
            return 1
        elif len(string1)<len(string2):
            return -1
        else: 
            return 0