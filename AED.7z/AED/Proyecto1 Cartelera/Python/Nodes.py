 #-*- coding: utf-8 -*-
from Movie import Movie
from Compare import *
from TimeManager import *

tm= TimeManager()
compare = Compare()

class NodeLinkedList:
    def __init__(self,value):
        self.value = value
        self.next = None


class NodeBST:
    def __init__(self,movie):
        if not isinstance(movie,Movie):
            return False        
        self.movie = movie
        self.left=None
        self.right=None
        self.key=movie.id
        self.height=1
        self.parent=None


class NodeTP:
    def __init__(self,value):
        self.value = value
        self.next=None
        from LinkedList import LinkedList
        self.children = LinkedList()


#final de Nodos#