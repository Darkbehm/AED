# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'gui.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from AsciiTable import *
from PushMovie import Ui_PushMovie
from Confirmation import Ui_Confirmation
class Ui_Table(object):
    def openPushWindow(self):
        inputNumber=self.textEdit_2.toPlainText()
        if not inputNumber.isdigit():
            return False
        if int(inputNumber)>self.main.linkedListData.length():
            return False
        
        self.windowPush=QtWidgets.QMainWindow()
        self.uiPush= Ui_PushMovie()
        self.uiPush.setupUi(self.windowPush,self.main,int(inputNumber))
        self.windowPush.show()

    def openConfirmDelete(self):
        inputNumber=self.textEdit_2.toPlainText()
        if not inputNumber.isdigit():
            return False
        if int(inputNumber)>self.main.linkedListData.length():
            return False

        self.windowConfirmation=QtWidgets.QMainWindow()
        self.uiConfirmation= Ui_Confirmation()
        self.uiConfirmation.setupUi(self.windowConfirmation,self.main,int(inputNumber))
        self.windowConfirmation.show()


    def setupUi(self, MainWindow,main):
        self.main=main
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(700, 540)
        MainWindow.setMaximumSize(700, 540)
        MainWindow.setMinimumSize(700, 540)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(20, 20, 660, 400))
        self.textEdit.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.textEdit.setLineWrapMode(QtWidgets.QTextEdit.NoWrap)
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setReadOnly(True)
        self.textEdit_2 = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit_2.setGeometry(QtCore.QRect(50,460, 71, 31))
        self.textEdit_2.setObjectName("textEdit_2")
        
        

        self.btnDelete = QtWidgets.QPushButton(self.centralwidget)
        self.btnDelete.setGeometry(QtCore.QRect(400, 440, 251, 71))
        self.btnDelete.setStyleSheet("background-color: rgb(224, 102, 101);\n"
        "color: rgb(255,255,255);\n"
        "border-radius: 30px;")
        self.btnDelete.setObjectName("btnDelete")
        self.btnDelete.clicked.connect(self.openConfirmDelete)

        self.btnEdit = QtWidgets.QPushButton(self.centralwidget)
        self.btnEdit.setGeometry(QtCore.QRect(135, 440,251, 71))
        self.btnEdit.setStyleSheet("background-color: rgb(109, 158, 235);\n"
"color: rgb(255, 255, 255);\n"
"border-radius: 30px")
        self.btnEdit.setObjectName("btnEdit")

        self.btnEdit.clicked.connect(self.openPushWindow)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Ver y Editar Listado"))
        self.textEdit.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.btnDelete.setText(_translate("MainWindow", "Eliminar"))
        self.btnEdit.setText(_translate("MainWindow", "Editar"))


