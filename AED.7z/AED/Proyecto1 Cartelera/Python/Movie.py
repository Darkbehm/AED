from Compare import Compare
from TimeManager import TimeManager
compare= Compare()
tm=TimeManager()

class Movie:
    def __init__(self,name,duration,director,description,categorie):
        self.name = name
        self.duration = duration
        self.director = director
        self.description = description
        self.categorie = categorie
        self.id=self.generateKey(duration)


    def generateNameKey(self):
        key=0
        for i in range(len(self.name)):
            key+=compare.alphabet.find(self.name[i])
        return key

    def generateKey(self,duration):
        duration=duration
        namekey=self.generateNameKey()
        value = tm.convertStringToInt(duration)*100000+namekey
        return value

    def __str__(self):
        description=self.description
        if len(description)>30:
            description=""
            for i in range(30):
                description+="%s"%self.description[i]
            description+= "..."
        
        name=""
        name += self.name
        if len(self.name)>17:
            name=""
            for i in range(17):
                name+="%s"%self.name[i]
            name+="...\t\t"
        elif len(self.name)>8:
            name=""
            for i in range(8):
                name+="%s"%self.name[i]
            name+="\t\t"
        else:
            name+="\t\t\t"
        
        return  "\t%s|\t%s\t\t|\t%s" %(name, self.duration, description)