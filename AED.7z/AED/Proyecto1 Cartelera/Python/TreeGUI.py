# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'TreeGUI.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


import sys
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from MatplotLibManager import MatplotlibManager 

class Ui_Tree(object):
    def setupUi(self, MainWindow,bst,tree):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(840,680)
        MainWindow.setMaximumSize(840,680)
        MainWindow.setMinimumSize(840,680)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.bstTree = Plot(self.centralwidget,bst)
        self.bstTree.setGeometry(QtCore.QRect(10, 0, 830, 325))
        self.bstTree.setObjectName("bstTree")

        self.categorieTree = PlotTree(self.centralwidget,tree)
        self.categorieTree.setGeometry(QtCore.QRect(10, 330, 830, 325))
        self.categorieTree.setObjectName("categorieTree")

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("Arboles", "Arboles"))

#plot para el bst
class Plot(QtWidgets.QWidget):
    def __init__(self,qwidget,bst):
        super(Plot, self).__init__(qwidget)
        self.initializewidget()
        self.plot1(bst)

    def initializewidget(self):
        self.setWindowTitle("BST")
        gridlayout = QtWidgets.QGridLayout()
        self.setLayout(gridlayout)

        self.figure = plt.figure(figsize=(20,10))



        self.canvas = FigureCanvas(self.figure)
        plt.close()
        navigationToolBar=NavigationToolbar(self.canvas,self)
    
        self.toolbar =navigationToolBar 
        gridlayout.addWidget(self.canvas,1,0,1,2)
        gridlayout.addWidget(self.toolbar,0,0,1,2)
        

    def plot1(self,bst):
        ax = self.figure.add_subplot(111)
    
        createTree(ax,2,bst)
        self.canvas.draw()
#plot para el arbol jerarquico
class PlotTree(QtWidgets.QWidget):
    def __init__(self,qwidget,tree):
        super(PlotTree, self).__init__(qwidget)
        self.initializewidget()
        self.plot1(tree)

    def initializewidget(self):
        self.setWindowTitle("Categorie Tree")
        gridlayout = QtWidgets.QGridLayout()
        self.setLayout(gridlayout)

        self.figure = plt.figure(figsize=(20,10))



        self.canvas = FigureCanvas(self.figure)
        plt.close()
        navigationToolBar=NavigationToolbar(self.canvas,self)
    
        self.toolbar =navigationToolBar 
        gridlayout.addWidget(self.canvas,1,0,1,2)
        gridlayout.addWidget(self.toolbar,0,0,1,2)
        

    def plot1(self,tree):
        ax = self.figure.add_subplot(111)
    
        createTree(ax,1,tree)
        self.canvas.draw()

def createTree(ax,treeSelect,tree):
    
    mplm= MatplotlibManager()

    if treeSelect==1:
        lis=tree.createListToPrint()
        mplm.createTreeFromLst(lis,ax)
    else:
        lis=tree.createListToPrint()
        mplm.createBSTFromLst(lis,ax)
    

"""
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    im = Ui_MainWindow()
    im.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
"""