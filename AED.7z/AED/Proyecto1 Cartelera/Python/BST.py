#-*-coding : utf-8 -*-
from LinkedList import *
from Nodes import NodeBST
from Movie import Movie
import math

class BST :
    def __init__ (self):
        self.root = None

    def printTree(self):
        if self.root :
            return self.printTreeInner(self.root)

    def printTreeInner(self,current):
        if current:
            self.printTreeInner(current.left)
            print ('%s,h=%d'%(str(current.movie.name),current.height))
            self.printTreeInner(current.right)
    
   # def generateList()

    def createListToPrint(self):
        bstList= []

        if not self.root:
            return bstList
        
        position = 0
        h = self.root.height
        mi = (pow(2,h-1))-1
        mf = mi*2
        w = mf+1

        middle= math.ceil(w/2)

        return self.addTobstListInner(self.root,bstList,middle)

    def addTobstListInner(self,current,bstList,x):
        if current:

            bstList=self.addTobstListInner(current.left,bstList,x-(current.height-1))
            
            node={'x':x,'y':current.height,'name':current.movie.name,'duration':current.movie.duration,'left':None,'right':None}

            if current.parent: 
                node['y']=current.parent.height-1
            
            if current.left:

                node['left']=[x-(current.height-1),current.height-1]

            if current.right:
                node['right']=[x+(current.height-1),current.height-1]
                  
            bstList.append(node)

            bstList=self.addTobstListInner(current.right,bstList,x+(current.height-1))  
        return bstList


    def generateStringDict(self):
        result='{"root":{'
        string=""
        if self.root:
            result+=self.generateStringDictInner(self.root,string)
            result+= '}}'
        else:
            result='{"root": None }'
        return result

    def generateStringDictInner(self,current,string):
        if current:
            string+= '"movie":{"name":"%s","duration":"%s","director":"%s","description":"%s","categorie":"%s"}, "left" : {'%(current.movie.name,current.movie.duration,current.movie.director,current.movie.description,current.movie.categorie)
            
            temporalString=""
            if current.left:
                temporalString =self.generateStringDictInner(current.left,temporalString)
                
            string+=temporalString
            string+="},"
            string+='"right":{'

            temporalString=""
            if current.right:
                temporalString=self.generateStringDictInner(current.right,temporalString)
            
            string+=temporalString            
            string+="}"
        return string




    def createLinkedList(self):
        linkedList= LinkedList()
        if not self.root:
            return linkedList
        
        position = 0

        linkedlist=self.addToLinkedListInner(self.root,linkedList)
        return linkedList
    

    def addToLinkedListInner(self,current,linkedList):
        if current:
            linkedlist=self.addToLinkedListInner(current.left,linkedList)
            linkedList.push({'name':current.movie.name,'duration':current.movie.duration,'director':current.movie.director,'description':current.movie.description,'categorie':current.movie.categorie})
            linkedlist=self.addToLinkedListInner(current.right,linkedList)
        return linkedList

    #add: metodo para añadir elementos al arbol este utiliza add inner para empezar desde la raiz del arbol
    #retorna:    True si lo agrego False si no lo agrego (si ya existia el nodo dentro del arbol)
    def __repr__(self):
        if not self.root :
            return ''
        content='\n'
        currentNodesAtLevel=[self.root]
        currentHeight=self.root.height
        sep='   '*(2**(currentHeight-1))

        while True:
            currentHeight += -1
            if len(currentNodesAtLevel)==0:
                break
            currenntRow='    '
            nextRow=''
            nextNode=[]

            if all(n is None for n in currentNodesAtLevel):
                break

            for n in currentNodesAtLevel:
                if not n:
                    currenntRow+='   '+sep
                    nextRow+= '   '+sep
                    nextNode.extend([None,None])
                    continue
                
                if n.key != None:
                    buf=' '*int((5-len(str(n.key)))/2)
                    currenntRow+='%s%s%s'%(buf,str(n.movie.name),buf)+sep
                else:
                    currenntRow+=' '*5+sep

                if n.left :
                    nextNode.append(n.left)
                    nextRow+='     /'+sep
                else:
                    nextRow+='      '+sep
                    nextNode.append(None)

                if n.right :
                    nextNode.append(n.right)
                    nextRow+='\     '+sep
                else:
                    nextRow+='      '+sep
                    nextNode.append(None)
            
            content+=(currentHeight*'     '+currenntRow+'\n'+currentHeight*'     '+nextRow+'\n')
            currentNodesAtLevel=nextNode
            sep=' '*int(len(sep)/2)
        return content

    def add(self,movie):
        if not isinstance(movie,Movie):
            return False
        node = NodeBST(movie)
        return self.addInner(node,self.root) 

    def addInner(self,node,current):
        if not self.root :
            self.root= node
            return True
        
        if not isinstance(current,NodeBST):
            return False

        if node.key < current.key:
            if not current.left:
                current.left = node
                current.left.parent=current

                self.inspectAdd(current.left)
                return True
            return self.addInner(node,current.left)

        elif node.key > current.key:  
            if not current.right:
                current.right = node
                current.right.parent = current

                self.inspectAdd(current.right)
                return True
            return self.addInner(node,current.right)
        
        else :
            return False 

    # search:
    #metodo para comprobar si un elemento existe 
    #dentro del arbol
    #    este utiliza search inner para empezar a buscar 
    #    desde la raiz del arbol
    #
    #retorna:    True si lo encontro
    #            False si no lo encontro

    def searchKey(self,key):
        return self.searchKeyInner(key,self.root)

    def searchKeyInner(self,key,current):
        if not self.root:
            return False
        
        if not isinstance(current,NodeBST):
            return False
        
        if not current :
            return False

        if current.key == key:
                return True

        elif current.key> key:
            if not current.left:
                return False
            return self.searchKeyInner(key,current.left)
        else:
            if not current.right:
                return False
            return self.searchKeyInner(key,current.right)

    def searchMovie(self,movie):
        if not isinstance(movie,Movie):
            return False
        temporalNode= NodeBST(movie)
        return self.searchKey(temporalNode.key)

    #devuelve un nodo buscandolo en el arbol a partir de un objeto pelicula, asi de este nodo podemos obtener la llave que se genera con el mismo
    #crea un nodo bst temporal y genera la llave luego esta llave la usamos para buscar el nodo a partir de la llave y asi nos devuelve el nodo 

    def findMovie(self,movie):
        if not isinstance(movie,Movie):
            return False
        
        temporalNode=NodeBST(movie)
        if self.searchKey(temporalNode.key):
            return self.findKey(temporalNode.key)
        else: return False

    #obtiene un nodo del arbol buscandolo con la llave
    def findKey(self,key):
        if not self.root:
            return None
        return self.findKeyInner(key,self.root)    


    def findKeyInner(self,key,current):
        if not isinstance(current,NodeBST):
            return False

        if key == current.key:
            return current
        elif key<current.key:
            if not current.left:
                return None
            return self.findKeyInner(key,current.left)
        else:
            if not current.right:
                return None
            return self.findKeyInner(key,current.right)
    

    def deleteKey(self,key):
        return self.deleteNode(self.findKey(key))
    
    def deleteMovie(self,movie):
        if not self.findMovie(movie):
            return False  
        return self.deleteKey(self.findMovie(movie).key)

    def deleteNode(self,node):

        #si  no se encuentra el nodo no se elimina(no se encontro el nodo ingresado en la funcion)
        if (not node) or (not self.findKey(node.key)):
            return None
        
        #encuentra el nodo con el key menor de los hijos del nodo ingresado
        def minimumKeyNode(currentNode):
            current= currentNode
            while current.left:
                current = current.left
            return current

        #encuentra cuantos hijos tiene el nodo a eliminar (0,1 o 2)
        def numberOfChildren(currentNode):
            count=0
            if currentNode.left:
                count+=1
            if currentNode.right:
                count+=1
            return count

        nodeParent=node.parent
        nodeChildren=numberOfChildren(node)

        #casos de eliminacion
        #caso 1 si no tiene hijos

        if nodeChildren==0:
            if nodeParent:
                if nodeParent.left==node:
                    nodeParent.left=None
                else: 
                    nodeParent.right=None
            else:
                self.root=None

        #caso 2 tiene un hijo

        if nodeChildren==1:
            #obtiene el hijo
            if node.left:
                child=node.left
            else:
                child = node.right

            # remplaza el nodo a borrar con el hijo
            if nodeParent:
                if nodeParent.left==node:
                    nodeParent.left=child
                else:
                    nodeParent.right=child
            else:
                self.root=child
            
            #cambia el parent del hijo para que no este con el nodo borrado, sino que con el parent del nodo borrado
            child.parent=nodeParent

        #caso 3 si tiene los dos hijos

        if nodeChildren==2:

            #obtiene el sucesor 'inorder' del nodo borrado
            succesor = minimumKeyNode(node.right)

            #copia el key del sucesor al nodo que queremos borrar 

            node.key=succesor.key
            node.movie=succesor.movie

            #elimina el sucesor ahora que su key a sido copiado al otro nodo
            self.deleteNode(succesor)

            return True

        if nodeParent:

            #corrige la altura del parent del nodo borrado
            #revisa que no exista desbalanceo en algun lugar del arbol luego de borrar algun nodo, lo recorre desde el padre hasta la raiz
            self.inspectDelete(node.parent)

    #metodo addLikedList agrega una linkedlist al arbol
    def addLinkedList(self,ll):
        if not isinstance(ll,LinkedList):
            return False
        current = ll.first
        while current:
            movie=current
            self.add(current.value)
            current=current.next
        return True
    
    #crea un arbol a partir de una linkedlist
    def createFromLinkedList(self,ll):
        if not isinstance(ll,LinkedList):
            return None
        
        tree=BST()
        tree.addLinkedList(ll)
        return tree
    
    #subtree devuelve un sub arbol buscando el valor que forma la raiz de este subarbol
    def subTree(self,value):
        return self.subTreeInner(value,self.root)

    #retorna un subarbol buscandolo con un value(key)
    def subTreeInner(self,value,current):
        if not self.root:
            return False
        
        if not isinstance(current,NodeBST):
            return False

        if current.key == value:
            tree = BST()
            tree.root= current
            return tree
        
        elif current.key>value:
            if not current.left:
                return False
            return self.subTreeInner(value,current.left)
        
        else:
            if not current.right:
                return False
            return self.subTreeInner(value,current.right)
    
    #obtiene la altura del arbol
    def height(self):
        if not self.root: return 0
        return self.innerHeight(self.root,0)

    def innerHeight(self,currentNode,currentHeight):
        if not currentNode: return currentHeight
        leftHeight= self.innerHeight(currentNode.left,currentHeight+1)
        rightHeight= self.innerHeight(currentNode.right,currentHeight+1)
        if leftHeight > rightHeight: 
            return leftHeight
        else: 
            return rightHeight

    #revisa que el arbol este balanceado luego de una adicion
    def inspectAdd(self,current,path=[]):
        if not current.parent:
            return True
        path=[current]+path
        leftHeight=self.getHeight(current.parent.left)
        rightHeight=self.getHeight(current.parent.right)
        
        if abs(leftHeight-rightHeight)>1:
            path=[current.parent]+path
            self.rebalanceNode(path[0],path[1],path[2])
            return True
        
        newHeight=1+current.height

        if newHeight>current.parent.height:
            current.parent.height=newHeight

        self.inspectAdd(current.parent,path)

    #inspecciona que el arbol este balanceado luego de una eliminacion
    def inspectDelete(self,current):
        # cuando se revisa la raiz el padre de esta es nulo entonces no se hace nada 
        if not current:
            return True

        leftHeight=self.getHeight(current.left)
        rightHeight=self.getHeight(current.right)


        if leftHeight>rightHeight:
            current.height=1+leftHeight
        else:
            current.height=1+rightHeight
        
        # se rebalanceara si la altura entre los hijos del current tiene una diferencia mayor que 1
        if abs(leftHeight-rightHeight)>1:
            nodeY=self.tallerChild(current)
            nodeX=self.tallerChild(nodeY)
            self.rebalanceNode(current,nodeY,nodeX)
        
        #aqui se aplicara recursivamente hasta llegar a la raiz
        self.inspectDelete(current.parent)



    #rebalancea los nodos z,y,x 
    def rebalanceNode(self,nodeZ,nodeY,nodeX):
        if nodeY==nodeZ.left and nodeX==nodeY.left:
            self.rightRotate(nodeZ)
        elif nodeY==nodeZ.left and nodeX==nodeY.right:
            self.leftRotate(nodeY)
            self.rightRotate(nodeZ)
        elif nodeY==nodeZ.right and nodeX==nodeY.right:
            self.leftRotate(nodeZ)
        elif nodeY==nodeZ.right and nodeX==nodeY.left:
            self.leftRotate(nodeZ)
            self.rightRotate(nodeY)
        else:
            raise Exception("rebalanceNode:la configuracion de nodos z,y,x no es correcta (no se reconoce)")
    
    #rotacion derecha
    def rightRotate(self,nodeZ):
        subRoot=nodeZ.parent
        nodeY=nodeZ.left
        temporal = nodeY.right
        nodeY.right=nodeZ
        nodeZ.parent=nodeY
        nodeZ.left=temporal
        
        if temporal:
            temporal.parent=nodeZ
        
        nodeY.parent=subRoot
        
        if not nodeY.parent:
            self.root=nodeY 
        else:
            if nodeY.parent.left==nodeZ:
                nodeY.parent.left=nodeY
            else:
                nodeY.parent.right=nodeY
        nodeZ.height=1+max(self.getHeight(nodeZ.left),self.getHeight(nodeZ.right))
        nodeY.height=1+max(self.getHeight(nodeY.left),self.getHeight(nodeY.right))
   
    #rotacion izquierda            
    def leftRotate(self,nodeZ):
        subRoot=nodeZ.parent
        nodeY=nodeZ.right
        temporal = nodeY.left
        nodeY.left=nodeZ
        nodeZ.parent=nodeY
        nodeZ.right=temporal
        
        if temporal:
            temporal.parent=nodeZ
        
        nodeY.parent=subRoot
        
        if not nodeY.parent:
            self.root=nodeY 
        else:
            if nodeY.parent.left==nodeZ:
                nodeY.parent.left=nodeY
            else:
                nodeY.parent.right=nodeY
        nodeZ.height=1+max(self.getHeight(nodeZ.left),self.getHeight(nodeZ.right))
        nodeY.height=1+max(self.getHeight(nodeY.left),self.getHeight(nodeY.right))

    #devuelve la altura de un nodo
    def getHeight(self,node):
        if not node:
            return 0
        return node.height

    #devuelve el hijo con mayor altura de un nodo
    def tallerChild(self,node):
        leftHeight=self.getHeight(node.left)
        rightHeight=self.getHeight(node.right)
        if leftHeight<rightHeight:
            return node.right
        else:
            return node.left

