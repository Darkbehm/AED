#-*- coding: utf-8 -*-#
from Nodes import NodeLinkedList
from Movie import Movie
class LinkedList:

    def __init__(self):
        self.first = None
        self.next = None

    def push(self,value,position=1):
        if isinstance(value,Movie):
            if not self.validateDuplicatedMovies(value):
                return True
            
        if(not isinstance(position,int) or position < 1):
            return False

        if(not self.first):
            self.first = NodeLinkedList(value)
            return True

        

        count = 1
        current = self.first

        if(count == position):
            queve = self.first
            self.first = NodeLinkedList(value)
            self.first.next = queve
            return True

        before =  self.first
        current = self.first.next

        while(current):
            count += 1
            if(count == position):
                before.next = NodeLinkedList(value)
                before.next.next = current
                return True

            before = current
            current = current.next
        before.next = NodeLinkedList(value)
        
    def print(self):
        reciep = ""
        current = self.first
        count = 1
        while(current):
            reciep += ("%s\t|%s\n")%(count,current.value)
            current = current.next
            count +=1   
                
        return reciep


    def length(self):
        count = 0
        current=self.first
        while(current):
            count+=1
            current = current.next
        return count 

    def delete(self,position=1):
        if(not isinstance(position,int) or position < 1):
            return False

        if(not self.first):
            return False

        if(position == 1):
            self.first = self.first.next
            return True

        count = 1
        before = self.first
        current = self.first.next
        while(current):
            count += 1
            if(position == count):
                before.next = current.next
                return True
            before = current
            current = current.next
        return False

    def search(self,value):
        if(not self.first):
            return False
        
        current = self.first
        while(current):
            if(current.value == value):
                return current.value
            current = current.next
        return False

    def find(self,value):
        if(not self.first):
            return False

        count=1
        current = self.first
        while(current):
            if(current.value.id == value.id):
                return count
            count+=1
            current = current.next
        return False

    def getById(self,position):
        if(not self.first):
            return False
        
        current = self.first
        count=1
        while(current):
            if(count == position):
                return current.value
            current = current.next
            count +=1
        return False

    def edit(self,value,position=0):
        if(not isinstance(position,int) or position < 1):
            return False
        if(not self.first):
            return False
        if(position == 0):
            return False
        count = 0 
        current = self.first
        while(current):
            count += 1
            if(count == position):
                current.value = value
                return True
            current = current.next
        return False      
    
    def __str__(self):
        return self.print() 

    def validateDuplicatedMovies(self,value):
        if not self.first:
            return True
        current= self.first
        
        while current:
            if value.name == current.value.name and  value.duration == current.value.duration and value.director==current.value.director and current.value.categorie == value.categorie:
                return False
            current=current.next
        
        return True
        